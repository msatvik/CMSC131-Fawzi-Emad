
public class FloatingPointError {

	public static void main(String[] args) {
		double x = 3.9;
		double y = 3.8; 
		if (x - y == 0.1) {
			System.out.println("I can do simple math.");
		} else {
			System.out.println("I am having trouble with easy problems.");
		}
	}
}
