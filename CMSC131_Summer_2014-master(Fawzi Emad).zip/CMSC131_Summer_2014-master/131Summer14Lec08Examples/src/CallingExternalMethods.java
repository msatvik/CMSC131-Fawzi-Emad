
public class CallingExternalMethods {

	
	public static void main(String[] args) {
	
		printChars('x', 50);
		printChars('@', 25);

	}
	
	public static void printChars(char characterToDraw, int numberOfChars) {
		for (int col = 0; col < numberOfChars; col++) {
			System.out.print(characterToDraw);
		}
		System.out.println();
	}

}
