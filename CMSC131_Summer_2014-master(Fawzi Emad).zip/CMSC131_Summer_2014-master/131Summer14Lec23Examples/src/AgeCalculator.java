import javax.swing.JOptionPane;
import java.util.Calendar;

public class AgeCalculator {

	private static int daysSince_01_01_1900(int month, int date, int year) {
		int days = (int)((year - 1900) * 365.25);
		switch(month) {
		case 12:
			days += 30;
		case 11:
			days += 31;
		case 10:
			days += 30;
		case 9:
			days += 31;
		case 8:
			days += 31;
		case 7:
			days += 30;
		case 6:
			days += 31;
		case 5:
			days += 30;
		case 4:
			days += 31;
		case 3:
			days += (year % 4 == 0)?  29 : 28;
		case 2:
			days += 31;
		}
		days += date;
		return days;
	}
	
	public static void main(String[] args) {
	
		String birthday = JOptionPane.showInputDialog("Enter your birthday (MM/DD/YYYY): ");
		
		int birthMonth = Integer.parseInt(birthday.substring(0, 2));
		int birthDay = Integer.parseInt(birthday.substring(3, 5));
		int birthYear = Integer.parseInt(birthday.substring(6, 10));

		Calendar calendar = Calendar.getInstance();
		int todayMonth = calendar.get(Calendar.MONTH) + 1;   // returns 0 for January!
		int todayDay = calendar.get(Calendar.DAY_OF_MONTH);
		int todayYear = calendar.get(Calendar.YEAR);
		
		int todayDays = daysSince_01_01_1900(todayMonth, todayDay, todayYear);
		int birthdayDays = daysSince_01_01_1900(birthMonth, birthDay, birthYear);
		
		int ageDays = (todayDays - birthdayDays);
		System.out.println("You are " + ageDays + " days old.");
		System.out.println("That is " + ageDays * 24 * 60 * 60 + " seonds!");
		
	}

}
