import java.util.Scanner;

public class Shapes {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("What size? ");
		int size = s.nextInt();
		
		// horizontal line
		for (int i = 1; i <= size; i++) {
			System.out.print("*");
		}
		System.out.println();
		
		// vertical line
		for (int i = 1; i <= size; i++) {
			System.out.println("*");
		}
		
		// triangle
		for (int row = 1; row <= size; row++) {
			for (int col = 1; col <= row; col++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		// diagonal
		for (int row = 1; row <= size; row++) {
			for (int col = 1; col < row; col++) {
				System.out.print(" ");
			}
			System.out.println("*");
		}
	}

}
