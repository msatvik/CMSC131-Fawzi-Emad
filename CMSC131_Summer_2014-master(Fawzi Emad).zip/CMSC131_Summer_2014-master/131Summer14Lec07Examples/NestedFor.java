
public class NestedFor {

	public static void main(String[] args) {

		for (int row = 1; row <= 9; row = row + 1) {
			for (int col = 1; col <= row; col = col + 1) {
				System.out.print(row);
			}
			System.out.println();
		}
	}

}
