
public class StringBufferExample {

	public static void main(String[] args) {
		StringBuffer stringBuffer = new StringBuffer();
		String string = new String();
		
		System.out.println("I will now concatenate 100000 copies of CAT using StringBuffer...");
		for (int i = 0; i < 100000; i++) {
			stringBuffer.append("CAT");
		}
		System.out.println("Done with that.  Now doing the same thing with Strings...");
		for (int i = 0; i < 100000; i++) {
			string += "CAT";
		}
		System.out.println("Done!");
	}

}
