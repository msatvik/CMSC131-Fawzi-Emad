public class Student {

	// instance vars
	public String name;
	public int ID;
	public int tokenLevel;

	// Constructors
	public Student(String nameIn, int tokensIn, int IDIn) {
		name = nameIn;
		tokenLevel = tokensIn;
		ID = IDIn;
	}

	public Student(String nameIn, int IDIn) {
		name = nameIn;
		ID = IDIn;
		tokenLevel = 3;
	}

	public Student() {
		name = "Unknown";
		ID = 0;
		tokenLevel = 3;
	}

	public Student(Student otherguy) {
		name = otherguy.name;
		ID = otherguy.ID;
		tokenLevel = otherguy.tokenLevel;
	}

	//instance methods
	public void sayHello() {
		System.out.println("Hello, my name is " + name + " and I have " + tokenLevel + " tokens.");
	}

	public void useToken() {
		if (tokenLevel <= 0) {
			throw new RuntimeException("you can't spend a token if you have none");
		}
		tokenLevel--;
	}

	public void acceptTokens(int numberOfTokens) {
		tokenLevel += numberOfTokens;
	}

	public void doProject(String project, int numPages) {
		System.out.println(name + " is working on " + project);
		for (int i = 0; i < numPages; i++) {
			System.out.println("done with page " + i);
		}
		System.out.println("FINISHED!!!");
	}

	public int getLastFour() {
		return ID % 10000;
	}

	public String eatLunch(String foodtype, int number) {
		String retValue;
		retValue = name + " is eating ";
		for (int i = 0; i < number; i++) {
			retValue += foodtype + " ";
		}
		retValue += ".";
		return retValue;
	}

	public boolean equals(Student otherGuy) {
		return ID == otherGuy.ID && tokenLevel == otherGuy.tokenLevel &&
		name.equals(otherGuy.name);
	}

	public String toString() {
		return "Name: " + name + ", ID: " + ID + ", tokens: " + tokenLevel;
	}

	/* static methods */
	public static void printPartners(Student a, Student b) {
		printLine('=');
		System.out.println(a);
		printLine('-');
		System.out.println(b);
		printLine('=');
	}
	
	public static void printLine(char c) {
		
		final int LINE_LENGTH = 40;
		
		int col = 0; 
		while (col < LINE_LENGTH) {
			System.out.print(c);
			col++;
		}
		System.out.println();
	}
}
