
public class EasyExample {

	static String x;
	
	public static void g() {
		System.out.println(x.length());
	}
	
	public static void f() {
		g();
	}
	
	public static void main(String[] args) {
		f();
	}

}
