
public class TriangleAreaCalculator {

	/* Calculate area of triangle given lengths of three sides.
	 * This formula is attributed to a guy named "Heron", but 
	 * was actually known to Archimedes!     
	 */
	public static double findArea(double s1, double s2, double s3) {
		double u = (s1 + s2 + s3) / 2;
		double v = u * (u - s1) * (u - s2) * (u - s3);
		if (v < 0) {
			throw new ArithmeticException("Illegal side lengths.");
		}
		return Math.sqrt(v);
	}
	
	
}
