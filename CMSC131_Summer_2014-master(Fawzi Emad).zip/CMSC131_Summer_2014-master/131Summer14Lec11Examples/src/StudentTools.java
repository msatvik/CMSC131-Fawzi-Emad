
public class StudentTools {
	
	public static void printPartners(Student a, Student b) {
		printLine('=');
		System.out.println(a);
		printLine('-');
		System.out.println(b);
		printLine('=');
	}
	
	public static void printLine(char c) {
		
		final int LINE_LENGTH = 40;
		
		int col = 0; 
		while (col < LINE_LENGTH) {
			System.out.print(c);
			col++;
		}
		System.out.println();
	}

}
