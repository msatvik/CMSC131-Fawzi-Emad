package twentyQuestions;

public interface CanHost20QuestionsGame {
	public String getName();
	public String answerQuestion(String question);
	public String getTaunt();
}
