package twentyQuestions;

public class Politician implements CanHost20QuestionsGame {
	
	private String[] taunts = {"I'm gonna lower taxes and extend government programs! What? There's a budget?",
			"I have vague unachieveable solutions to all of your problems!",
			"I'm a regular person just like you!  This one time... I even bought my own groceries!"};
	
	private String lastAnswer;
	
	public Politician() {
		lastAnswer = (Math.random() < .5)? "YES":"NO";
	}
	
	public String getName() {
		return "U.S. Congressman";
	}
	
	public String getTaunt() {
		int tauntSelection = (int)(Math.random() * taunts.length);
		return taunts[tauntSelection];
	} 
	
	public String answerQuestion(String q) {
		if (lastAnswer.equals("YES"))
			lastAnswer = "NO";
		else
			lastAnswer = "YES";
		return lastAnswer;
	}
}
