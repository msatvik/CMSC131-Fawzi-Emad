
public class GiantBinary {

	public static void drawZero(int size){

		for(int rowNum=0; rowNum<3; rowNum++){
			for(int colNum=0; colNum<size; colNum++){
				System.out.print("0");
			}
			System.out.println();
		}
		for(int rowNum)
		/*
			for(int rowNum3=size-6; rowNum3<=size-6; rowNum3++){
				System.out.print("1");
				for(int colNum3=size-6;colNum3<=size-6;colNum3++){
			    System.out.println("1");
			}
		}
		*/
	}
	
	public static void drawOne(int size){
		for(int rowNum=0; rowNum<=size; rowNum++){
			System.out.println();
			for(int colNum=0;colNum<=size;colNum++){
				System.out.print("1");
			}
		}
	}
	public static void main(String[] args){
		drawZero(9);
	}


}
