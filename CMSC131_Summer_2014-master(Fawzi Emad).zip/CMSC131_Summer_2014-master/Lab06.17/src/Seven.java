import java.util.Scanner;

public class Seven {
	public static void main(String []args){
		
		int row, col, usersInput;
		
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please Enter a Positive Integer: ");
		usersInput = input.nextInt();
		
		for(row=1; usersInput==11;row++){
			for(col=1; usersInput<=11; col++){
				System.out.println("*");
			}
			System.out.println(".");
		}
	}

}
