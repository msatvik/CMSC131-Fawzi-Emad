
public class Six {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean peter = ((3 < 5) && !(1 > 14)) && (-5 < -15) || ((6 == 6) && !(2 == 2));
		boolean peter2 =(-5 < -15); //|| ((6 == 6) && !(2 == 2));
		
		System.out.print(peter2);

	}

}
