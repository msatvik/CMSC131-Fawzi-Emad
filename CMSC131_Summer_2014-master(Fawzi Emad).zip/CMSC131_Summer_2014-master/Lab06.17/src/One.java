import java.util.Scanner;

public class One {
	
	public static void printDollarStars(int userInput){
		for(int lineIndex = 0; lineIndex < userInput; lineIndex++){
			for(int numberIndex=1; numberIndex <userInput; numberIndex++){
				
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter a positive integer ");
		int userInput = scan.nextInt();
		
		if(userInput > 0){
			System.out.println(userInput);
		}
		scan.close();

	}

}
