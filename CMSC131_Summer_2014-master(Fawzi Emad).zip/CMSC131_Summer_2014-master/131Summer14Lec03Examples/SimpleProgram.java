/* This is a very basic Java program to get things started.  */

public class SimpleProgram {

     public static void main (String args[]) {    // where the program starts
          System.out.println("Hello World!");
          System.out.print("Or maybe I should say: ");
          System.out.println("Goodbye World!");
          System.out.println("I don't know.");
     }
     
}
