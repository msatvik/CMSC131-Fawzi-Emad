package tourFramework;

public interface Tourist {
	public void travelTo(String attraction);
	public void commentOn(String attraction);
}
