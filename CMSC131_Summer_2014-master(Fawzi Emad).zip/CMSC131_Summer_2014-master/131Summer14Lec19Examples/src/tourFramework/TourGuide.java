package tourFramework;

public interface TourGuide {
	public void sayGreeting();
	public String[] listAttractions();
	public void directVisitorsTo(String attraction);
	public void describe(String attraction);
	public void sayGoodbye();
}
