package tourFramework;
import guides.*;
import tourists.*;
import both.*;

public class Driver {

	public static void main(String[] args) {
		TourGuide guide;
		Tourist[] visitors = new Tourist[3];
		
		guide = new LasVegasTourGuide();
		visitors[0] = new UMStudent();
		visitors[1] = new SeniorCitizen();
		visitors[2] = new Teenager();
		Tours.conductTour(guide, visitors);
	}

}
