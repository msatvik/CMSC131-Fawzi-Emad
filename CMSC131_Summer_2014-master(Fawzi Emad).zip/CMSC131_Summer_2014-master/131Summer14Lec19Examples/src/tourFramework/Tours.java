package tourFramework;

public class Tours {

	public static void conductTour(TourGuide guide, Tourist[] tourists) {
		guide.sayGreeting();
		String[] attractions = guide.listAttractions();
		for (int i = 0; i < attractions.length; i++) {
			guide.directVisitorsTo(attractions[i]);
			for(int j = 0; j < tourists.length; j++) {
				tourists[j].travelTo(attractions[i]);
			}
			guide.describe(attractions[i]);
			for (int j = 0; j < tourists.length; j++) {
				if (Math.random() < .25) {
					tourists[j].commentOn(attractions[i]);
				}
			}
		}
		guide.sayGoodbye();
	}

}
