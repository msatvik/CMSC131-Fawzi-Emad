package guides;
import tourFramework.TourGuide;

public class ParisTourGuide implements TourGuide {
	
	public void sayGreeting() {
		System.out.println("Bonjour, mes amis!  Bienvenue � Paris!");
	}
	
	public String[] listAttractions() {
		String[] attractions = {"Eiffel Tower", "Arc de Triomphe",
				"Louvre", "Napolean's Tomb"};
		return attractions;
	}
	
	public void directVisitorsTo(String attraction) {
		System.out.println("Rencontrez-moi � " + attraction + "...");
	}
	
	public void describe(String attraction) {
		System.out.println("Regardez " + attraction + "!");
	}

	public void sayGoodbye() {
		System.out.println("Au revoir, mes amis!");		
	}
}
