package guides;
import tourFramework.TourGuide;

public class LasVegasTourGuide implements TourGuide {

	public void sayGreeting() {
		System.out.println("Welcome to Fabulous Las Vegas, Nevada!");
	}
	
	public String[] listAttractions() {
		String[] attractions = {"Bellagio", "Caesar's Palace",
				"Venetian", "Treasure Island"};
		return attractions;
	}
	
	public void directVisitorsTo(String attraction) {
		System.out.println("OK, folks... meet me at the " + attraction + "...");
	}
	
	public void describe(String attraction) {
		System.out.println("Behold the spectacular " + attraction + "!");
	}

	public void sayGoodbye() {
		System.out.println("Thank you for visiting, and remember: " +
				"What happens in Vegas stays in Vegas!");		
	}

}
