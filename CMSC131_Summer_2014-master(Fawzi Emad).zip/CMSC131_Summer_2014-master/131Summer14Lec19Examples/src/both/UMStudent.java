package both;
import tourFramework.*;

public class UMStudent implements TourGuide, Tourist {

	public void sayGreeting() {
		System.out.println("Hey everybody -- welcome to Maryland!");
	}
	
	public String[] listAttractions() {
		String[] attractions = {"Student Union", "Hornbake Library",
				"North Gym", "CSIC Building"};
		return attractions;
	}
	
	public void directVisitorsTo(String attraction) {
		System.out.println("Let's all head over to the " + attraction + "...");
	}
	
	public void describe(String attraction) {
		System.out.println("Hey guys, check out the " + attraction + "!");
	}

	public void sayGoodbye() {
		System.out.println("It's been a lot of fun -- see you around campus!");		
	}

	public void commentOn(String attraction) {
		System.out.println("Dude, the " + attraction + " is so awesome!");
	}

	public void travelTo(String attraction) {
		System.out.println("Walking to " + attraction + "...");
	}

}
