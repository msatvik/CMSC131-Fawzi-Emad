package tourists;

import tourFramework.Tourist;

public class Teenager implements Tourist {
	
	public void travelTo(String attraction) {
		System.out.println("Riding bicycle to " + attraction + "...");
	}
	
	public void commentOn(String attraction) {
		System.out.println("Whatever.");
	}
}
