package tourists;

import tourFramework.Tourist;

public class SeniorCitizen implements Tourist {

	public void travelTo(String attraction) {
		System.out.println("Driving golf cart to " + attraction + "...");
	}
	
	public void commentOn(String attraction) {
		System.out.println("In my day, the " + attraction + " was better. " + 
				"Did I ever tell you the story about...  " + 
				"Say, is that the " + attraction + "?");
	}
}
