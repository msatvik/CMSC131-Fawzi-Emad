package CDExamples;

public class RewriteableCDCollectionOwner {

	private String name;
	private RewriteableCD[] myFavorites;
	
	public RewriteableCDCollectionOwner() {
		name = "Fawzi";
		myFavorites = new RewriteableCD[2];
		myFavorites[0] = new RewriteableCD("Rolling Stones", "Exile on Main Street");
		myFavorites[1] = new RewriteableCD("Van Halen", "Fair Warning");
	}
	
	public RewriteableCD[] getCDsReferenceCopy() {
		return myFavorites;
	}
	
	public RewriteableCD[] getCDsShallowCopy() {
		RewriteableCD[] copy = new RewriteableCD[myFavorites.length];
		for (int i = 0; i < copy.length; i++)
			copy[i] = myFavorites[i];
		return copy;
	}
	
	public RewriteableCD[] getCDsDeepCopy() {
		RewriteableCD[] copy = new RewriteableCD[myFavorites.length];
		for (int i = 0; i < copy.length; i++)
			copy[i] = new RewriteableCD(myFavorites[i]);
		return copy;
	}
	
	public String toString(){
		String s = name + "\n";
		s += myFavorites[0] + " & " + myFavorites[1] + "\n";
		s += "------------------";
		return s;
	}
}
