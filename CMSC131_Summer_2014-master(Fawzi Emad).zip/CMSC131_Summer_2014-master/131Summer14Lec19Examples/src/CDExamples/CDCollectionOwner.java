package CDExamples;

public class CDCollectionOwner {

	private String name;
	private CD[] myFavorites;
	
	public CDCollectionOwner() {
		name = "Fawzi";
		myFavorites = new CD[2];
		myFavorites[0] = new CD("Rolling Stones", "Exile on Main Street");
		myFavorites[1] = new CD("Van Halen", "Fair Warning");
	}
	
	public CD[] getCDsReferenceCopy() {
		return myFavorites;
	}
	
	public CD[] getCDsShallowCopy() {
		CD[] copy = new CD[myFavorites.length];
		for (int i = 0; i < copy.length; i++)
			copy[i] = myFavorites[i];
		return copy;
	}
	
	public CD[] getCDsDeepCopy() {
		CD[] copy = new CD[myFavorites.length];
		for (int i = 0; i < copy.length; i++)
			copy[i] = new CD(myFavorites[i]);
		return copy;
	}
	
	public String toString(){
		String s = name + "\n";
		s += myFavorites[0] + " & " + myFavorites[1] + "\n";
		s += "------------------";
		return s;
	}
}
