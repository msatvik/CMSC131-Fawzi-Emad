package CDExamples;

public class RewriteableCDOwner {

	private String name;
	private RewriteableCD myFavorite;
	
	public RewriteableCDOwner() {
		name = "Fawzi";
		myFavorite = new RewriteableCD("Led Zeppelin", "Houses of the Holy");
	}
	
	public RewriteableCD getCD() {
		return myFavorite;
	}

	public RewriteableCD getCDAlternative() {
		return new RewriteableCD(myFavorite);
	}
}
