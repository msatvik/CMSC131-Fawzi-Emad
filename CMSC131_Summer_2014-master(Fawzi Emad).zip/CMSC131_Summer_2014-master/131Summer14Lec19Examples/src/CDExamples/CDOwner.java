package CDExamples;

public class CDOwner {

	private String name;
	private CD myFavorite;
	
	public CDOwner() {
		name = "Fawzi";
		myFavorite = new CD("Led Zeppelin", "Houses of the Holy");
	}
	
	public CD getCD() {
		return myFavorite;
	}
	
	public CD getCDAlternative() {
		return new CD(myFavorite);
	}

}
