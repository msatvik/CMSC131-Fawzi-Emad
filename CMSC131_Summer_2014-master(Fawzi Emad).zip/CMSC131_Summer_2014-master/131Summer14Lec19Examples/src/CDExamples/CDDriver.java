package CDExamples;

public class CDDriver {

	/**
	 * Shows the use of the CD and RewritebleCD classes
	 * as well as their owners and collectors
	 */
	public static void main(String[] args) {
		System.out.println("****Regular CD ***");
		CDCollectionOwner p = new CDCollectionOwner();
		CD myFav = new CD("Barry Manilow","One Voice");
		CD[] a = p.getCDsReferenceCopy();
		a[0] = myFav;
		System.out.println("after reference copy:");
		System.out.println(p);
		CDCollectionOwner newp = new CDCollectionOwner();
		CD[] newa = newp.getCDsShallowCopy();
		newa[0] = myFav;
		System.out.println("after shallow copy:");
		System.out.println(newp);
		System.out.println("***Rewritable CD***");
		RewriteableCDCollectionOwner q = new RewriteableCDCollectionOwner();
		RewriteableCD[] b = q.getCDsShallowCopy();
		b[0].rewrite("Barry Manilow","One Voice");
		System.out.println("after shallow copy:");
		System.out.println(q);
		RewriteableCDCollectionOwner newq = new RewriteableCDCollectionOwner();
		RewriteableCD[] newb = newq.getCDsDeepCopy();
		newb[0].rewrite("Barry Manilow", "One Voice");
		System.out.println("after deep copy:");
		System.out.println(newq);
	}

}
