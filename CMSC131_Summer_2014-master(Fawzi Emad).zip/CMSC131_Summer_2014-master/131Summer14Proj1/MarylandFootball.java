import java.util.Scanner;

public class MarylandFootball {

	public static void main(String[] args) {


		int numberChosen, jerseyNumber, selectedJerseyNumber;
		String playersName, nameChosen;

		Scanner input = new Scanner(System.in);

		System.out.print("Type 1 to enter a number or 2 to enter a name: ");
		numberChosen = input.nextInt();

		if(numberChosen == 1){
			System.out.print("Enter player number: ");
			jerseyNumber = input.nextInt();

			if(jerseyNumber == 1 || jerseyNumber== 15 || jerseyNumber==16 || jerseyNumber==45){
				System.out.print("Which player wears number " +jerseyNumber+ " on his jersey? ");
				playersName = input.next();
				if((jerseyNumber ==1 && playersName.equals("Diggs"))          || 
						(jerseyNumber==15 && playersName.equals("Craddock")) ||
						(jerseyNumber==16 && playersName.equals("Brown"))    ||
						(jerseyNumber==45 && playersName.equals("Ross")) ){
					System.out.println("Correct!");
				}else{
					System.out.println("Incorrect!");
				}

			}else{
				System.out.println("Invalid Choice.");
			}
		}else{


			/*starts second part of the program for option number 2 */


			if(numberChosen == 2){

				System.out.print("Choose a name: ");
				nameChosen = input.next();

				if(nameChosen.equals("Diggs")       ||
						nameChosen.equals("Craddock")||
						nameChosen.equals("Brown")  ||
						nameChosen.equals("Ross")){

					System.out.print("What number does " +nameChosen+ " wear? ");
					selectedJerseyNumber = input.nextInt();

					if((selectedJerseyNumber==1 && nameChosen.equals("Diggs"))          || 
							(selectedJerseyNumber==15 && nameChosen.equals("Craddock")) ||
							(selectedJerseyNumber==16 && nameChosen.equals("Brown"))    ||
							(selectedJerseyNumber==45 && nameChosen.equals("Ross")) ){
						System.out.println("Correct!");
					}else{
						System.out.println("Incorrect!");
					}
				}else{
					System.out.println("Invalid Choice.");
				}
			}
		}
	}
}
