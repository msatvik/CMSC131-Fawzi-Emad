import java.util.Scanner;

public class MidtermStudy {

	public static void main(String[] args) {

		/*
		 * 
		 *  WEEK 3 STUDY QUESTIONS 


1) What are the three logical operators?  &&, ||, !


2) Write "truth-tables" for && and ||.

A		B		&&		||
T		T		T		T
T		F		F		T
F		T		F		T
F		F		F		F


3) Is the following boolean expression true or false? ((3 < 5) && !(1 > 14) && (-5 < -15)) || ((6 == 6) && !(2 == 2))

FALSE

4) If s1 and s2 are variables representing Strings, what Java boolean expression is equivalent to "s1 is not the same as s2"?

!s1.equals(s2);

5) What statement must be included at the top of a file in order to use the Scanner in the file?

import java.util.Scanner; OR import java.util.* (this will include everything that is in the util folder

6) Write a java class called "UserInput". In the main method, declare three variables: an int, a float, and a String. Name the variables "age", "weight", and "name". Create a variable called "scan" of type Scanner, and set it equal to a new Scanner. (Use the syntax shown in class). Prompt the user to enter his/her age, weight, and name, then read these entries in using the scanner and set the variables accordingly. Then print the values of the three variables with appropriate labels. For example: "Name: Frank Age: 17 weight: 151.4".

public Class UserInput{
	public static void main(String []args){

	int age;
	float weight;
	String name;

	Scanner scan = new Scanner(System.in);

	System.out.print("Please enter your age: ");
	age = scan.nextInt();
	System.out.print("Weight: ");
	weight = scan.nextFloat();
	scan.next();
	System.out.print("name: ");
	name = scan.nextLine();

	 System.out.print("Name: "+name+ " Age: "+age+ " weight: "+weight);
}

7) Write a java class called "FahrenheitToCelcius". The main method will ask the user to enter a temperature in Fahrenheit. (Use a variable of type "double" to store the value.) Then calculate the equivalent temperature in Celcius, and print out a message telling the user what you found. [Recall: C = (5/9)(F-32).] Hint: Be careful about doing arithmetic with integers! Check your program by entering 212 degrees. The output should be 100.

Modify the "FahrenheitToCelcius" question in the previous question so that the user can either go from F to C or vice versa.

FOR THIS EXERCISE, YOU SHOULD STRIVE TO AVOID REDUNDANT CODE! Write a java class called "RequestInfo". The main method will ask the user to enter his species. If the user enters "dog", then ask him to enter the number of cats he has eaten this year. If the user enters "cat", ask him to enter the number of hairballs he has coughed up this year. If the user enters "human", ask him to enter BOTH the number of cats he has eaten this year AND the number of hairballs he has coughed up this year. If the user enters anything else (not dog, cat or human), tell him that he is from another planet, and terminate the program. If the user DID enter one of the three valid species (dog, cat, human) then print out a report in the following format:
        Species:  dog

        Number of cats eaten:  54

        Number of hairballs:  0

Write a program that computes the letter grade for a student based on his/her numerical total. The program will read in the total and compute the letter grade based on the following: to get an A the total must be at least 90.0. To get a B it must be at least 80.0. For a C, at least 70.0. For a D, at least 60.0. Less than 60.0 is an F.
Write a program that asks the user to enter up to four scores from 1 to 10. At the end the program will print out the total of the scores, but without including the highest score. The catch is that at any time the user may enter 999 to indicate that he has no more scores to report. YOU MAY NOT USE ANY LOOPS! For example, here are a couple of possible runs of the program:
Example 1:

	Enter score 1:  5
	Enter score 2:  7
	Enter score 3:  9
	Enter score 4:  3
	The total (without the highest) was: 15

Example 2:

	Enter score 1:  8
	Enter score 2:  9
	Enter score 3:  999
	The total (without the highest) was: 8

Decide which of the following variable names are valid in Java: dog, x11, _tomato, big$deal, how&why, 22down, aBcDeFg, _$__$, under_score, _5_$_5_hello13.

Write a program that asks the user for an integer, call it n. The program will then add up all of the integers from 1 to n and print out the total. For example, if the user enters 4, then the output should be 10. (Because 1 + 2 + 3 + 4 = 10).

The factorial of an integer is the product of all positive integers that are less than or equal to it. For example, 4 factorial is 2 * 3 * 4 = 24. Write a program that asks the user to enter a value, n, and then prints n factorial.

Write a program that asks the user to enter two values: x and y. You must then compute the product of all integers from x to y. For example, if the user has entered 10 and 7, then the output should be 5040 (because 7 * 8 * 9 * 10 = 5040).

Write a program that simulates the reading password process you go through while logging into a computer account. The program will ask for a password, compare the value against two possible passwords (that are built-in), and print "Welcome" if the password provided by the user is valid. Otherwise, ask the user to enter the password again. (This process repeats.)

Write a program that asks the user to enter the number of rows and columns. It will then print out a rectangular grid of asterisks. For example, if the user has entered 6 rows and 3 columns, then the output should be:

		 ***
		 ***
		 ***
		 ***
		 ***
		 ***

Write a program that asks the user for a size (an integer). The program will then print out four different triangles made out of asterisks of that size. (You will need to print out spaces sometimes in front of the asterisks.) Below is the output if the user selected size 4:

		 ****
		 ***
		 **
		 *


		 *
		 **
		 ***
		 ****


		 ****
		 ***
		 **
		 *


		 *
		 **
		 ***
		 ****

Write a program that asks the user for a size, and then prints out a multiplication table of that size. (You don't have to worry about spacing correctly, just try to get the numbers to all come out on the right rows.) For example, if the user requests size 4, the output should be:
1 2 3 4
2 4 6 8
3 6 9 15
4 8 12 16
		 */

		//answerNumber6();
		//answerNumber7();
		//answerNumber8();
		//answerNumber9();
		//answerNumber10();
		answerNumber18();

	}











	public static void answerNumber6(){
		int age;
		float weight;
		String name;

		Scanner scan = new Scanner(System.in);

		System.out.print("Please enter your age: ");
		age = scan.nextInt();
		System.out.print("Weight: ");
		weight = scan.nextFloat();
		System.out.print("name: ");
		name = scan.next();
		System.out.print("Name: "+name+ " Age: "+age+ " weight: "+weight);
	}




















	/*7) Write a java class called "FahrenheitToCelcius". The main method will 
	 *  ask the user to enter a temperature in Fahrenheit. (Use a variable of type
	 *  "double" to store the value.) Then calculate the equivalent temperature in Celcius, 
	 *  and print out a message telling the user what you found. [Recall: C = (5/9)(F-32).] H
	 *  int: Be careful about doing arithmetic with integers! Check your program by entering 212 degrees. 
	 *  The output should be 100.
	 */
	public static void answerNumber7(){
		double givenTemperature;


		Scanner input = new Scanner(System.in);
		System.out.print("please enter fahrenheit temperature: ");
		givenTemperature = input.nextDouble();
		double celsius = 5.0/9.0 * (givenTemperature-32);
		System.out.print("I found that "+givenTemperature+"degrees F in celsius is: "+celsius);
		System.out.println();

	}















	public static void answerNumber8(){
		double fahrenheit =1, celsius;
		int option;

		Scanner input = new Scanner(System.in);

		System.out.print("please enter 1 for fahrenheiht: \n     or \n2 for celsius:");
		option = input.nextInt();

		if(option == 2){
			System.out.print("please enter celsius temperature: ");
			celsius = input.nextDouble();
			celsius = 5.0/9.0 * (fahrenheit-32);
			System.out.print("I found that "+fahrenheit+" degrees F in celsius is: "+celsius);
		}else

			System.out.print("please enter fahrenheit temperature: ");
		fahrenheit = input.nextDouble();
		celsius = 5.0/9.0 * (fahrenheit-32);


		System.out.print("I found that "+fahrenheit+" degrees F in celsius is: "+celsius);
		System.out.println();

	}
















	public static void answerNumber9(){

		Scanner scanner = new Scanner(System.in);
		System.out.print("What is your species?  ");
		String answer = scanner.next();
		int catsEaten = 0, hairballs = 0;
		if (answer.equals("dog") || answer.equals("cat") || answer.equals("human")) {
			if (!answer.equals("cat")) {
				System.out.print("How many cats have you eaten this year?  ");
				catsEaten = scanner.nextInt();
			}
			if (!answer.equals("dog")) {
				System.out.println("How many hairballs have you coughed up this year?  ");
				hairballs = scanner.nextInt();
			}
			System.out.println("Species:  " + answer);
			System.out.println("Number of cats eaten:  " + catsEaten);
			System.out.println("Number of hairballs:  " + hairballs);
		} else {
			System.out.println("You are from another planet!");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void answerNumber10(){
		 Scanner scanner = new Scanner(System.in);
	        System.out.print("What is your numerical total:  ");
	        double total = scanner.nextDouble();
	        char grade;
	        if (total >= 90.0) {
	            grade = 'A';
	        } else if (total >= 80.0) {
	            grade = 'B';
	        } else if (total >= 70.0) {
	            grade = 'C';
	        } else if (total >= 60.0) {
	            grade = 'D';
	        } else {
	            grade = 'F';
	        }
	        System.out.println("Your grade is " + grade);
	    }
	
	
	public static void answerNumber18(){
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Size: ");
		int size = input.nextInt();
		/*
		for(int row=0;row<=size;row++){
			for(int col=0;col<row;col++){
				System.out.print("*");
			}
			System.out.println("");
		}
		*/
		
		for(int row2=0; row2<=size;row2++){
			for(int col2=size; col2>=size; col2--){
				System.out.print("*");
			}
			System.out.println("");
		}
	}
	}



