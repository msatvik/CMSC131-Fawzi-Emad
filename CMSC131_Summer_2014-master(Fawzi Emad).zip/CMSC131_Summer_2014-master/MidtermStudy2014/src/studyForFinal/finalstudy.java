package studyForFinal;

public class finalstudy {
}

public class Fish{}
	//assume that there is a mutable class called Fish, which is
	//equipped with a copy constructor. Consider the class Below, 
	//which is only partially shown

public class Aquarium{
	
	private Fish[] fishArray;
	
	public Fish[] getterOne(){
		Fish[] copy = new Fish[fishArray.length];
		for(int i=0; i<fishArray.length;i++){
			copy[i] = new Fish(fishArray[i]);
		}
		return copy;
	}
	
	public Fish[] getterTwo(){
		Fish[] copy = new Fish[fishArray.length];
		for(int i=0;i<fishArray.length;i++){
			copy[i] = fishArray[i];
		}
		return copy;
	}
	
	public Fish[] getterThree(){
		return fishArray;
	}
	
	//a) what kind of copy is made in getterOne?
	
	/*deep copy */
	
	//b)what kind of copy is made in gettterTwo?
	
	/*shallow copy*/
	
	//c)what kind of copy is made in getterThree?
	
	/*reference copy*/
	
	//d)Which of these getters would allow someone to modify 
	////a particular Fish that is part of an existing Aquarium
	////after that getter was used? 
	
	
	//e)Which of these getters would allow someone to replace a 
	////a particular Fish that is part of an existing Aquarium with a Fish of 
	////their choosing after that getter was used?
	
	
	//f)(10points) Write an instance method for the Aquarium class called
	////deleteLastFish with the prototype you see below. The method will delete 
	///the last fish in the aquarium(the last entry in the array). The resulting 
	///array must be re-sized so that there are no null entries. If the aquarium
	///is empty when this method is called then it should throw an IllegalStateException
	
	
	public void deleteLastFish(){
		
		if(fishArray.length == 0){
			throw new IllegalStateException();
		}
		Fish[] s = new Fish[fishArray.length-1]; //why is this minus one?
		for(int i=0; i<s.length;i++){
			s[i] = fishArray[i];
		}
		fishArray = s;
	}
	
	public void deleteFish2(){
		if(fishArray.length == 0){
			throw new IllegalStateException();
		}
		Fish[] f = new Fish[fishArray.length-1];
		for(int i=0;i<f.length; i++){
			f[i] = fishArray[i];
		}
		fishArray = f;
	}
	
	public void deleteFish3(){
		if(fishArray.length == 0){
			throw new IllegalStateException();
		}
		Fish[] g = new Fish[fishArray.length-1];
		for(int i=0;i<g.length; i++){
			g[i] = fishArray[i];
		}
		fishArray = g;
	}
	
	public void deleteFish4(){
		if(fishArray.length == 0){
			throw new IllegalStateException();
		}
		Fish[] h = new Fish[fishArray.length-1];
		for(int i=0;i<h.length;i++){
			h[i] = fishArray[i];
		}
		fishArray = h;
	}
	
	public void deleteFish5(){
		if(fishArray.length == 0){
			throw new IllegalStateException();
		}
		Fish[] j = new Fish[fishArray.length-1];
		for(int i=0; i<j.length; i++){
			j[i] = fishArray[i];
		}
		fishArray = j;
	}
}

//Problem #5



//write a method with the prototype you see below. The return value will be a "ragged"
//2-Dimensional array. The lengths of the two parameters "rowSizes" and "data" will be the same.
//The array rowSizes will be used to specify how many elements appear in each row of the return value.
//The array "data" contains values that will be used to fill the corresponding rows.


//for example: if rowSize is the array <2,3,5>, and data is the array <7,0,9>, then 
//the return value would be the ragged array that looks like this:

//77
//000
//99999

public class assdfs{ 
	public static int[][] raggedArrayMaker(int[] rowSizes, int[] data){

		int [][] raggedArray = new int[data.length][];
		for(int x=0;x<raggedArray.length;x++){
			raggedArray[x] = new int[rowSizes[x]];
		}
		for(int i=0;i<raggedArray.length;i++){
			for(int j=0;j<raggedArray[i].length;j++){
				raggedArray[i][j] = data[i];
			}
		}
		return raggedArray;
	}
}


















































