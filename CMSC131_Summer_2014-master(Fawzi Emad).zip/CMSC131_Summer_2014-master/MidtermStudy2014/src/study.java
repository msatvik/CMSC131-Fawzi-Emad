
public class study {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("follow link for practice exams");
		System.out.println("http://www.cs.umd.edu/class/sum2005/cmsc131/exams.shtml");
		System.out.println("http://www.cs.umd.edu/class/spring2011/cmsc131-020x/exams.shtml");
		
		for(int i=0; i<5;i++){
			switch(i){
			case 0:
				System.out.println("m");
				break;
			case 1:
			case 2:
				System.out.println("o");
				break;
			case 3:
				System.out.println("d");
			case 4:
				System.out.println("!");
				break;
			}
		}
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				System.out.println("i="+i+"j="+j);
				
			}
		}
	}
	
	public static void foo(int x){
		if(x==2){
			throw new NullPointerException();
		}else if(x==3){
			throw new NumberFormatException();
		}
		System.out.println("A");
	}
		
	

}
