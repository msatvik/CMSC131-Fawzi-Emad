
public class SimpleDoWhile {
	
	public static void main(String[] args) {
		int index = 1;
		do {
			System.out.println(index);
			index = index + 1;
		} while(index <= 10);
	}
}

