
public class SimpleWhile {
	public static void main(String[] args) {
		int counter = 1;
		while (counter <= 10) {
			System.out.println(counter);
			counter = counter + 1;
		}
		System.out.println("DONE");
	}
}

