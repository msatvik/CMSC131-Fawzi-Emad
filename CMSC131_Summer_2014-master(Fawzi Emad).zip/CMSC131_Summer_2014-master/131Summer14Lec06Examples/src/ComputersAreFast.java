/* This example will do a billion addition problems in a couple of
 * seconds.  Computers are useful because they are FAST!!
 */

public class ComputersAreFast {

	public static void main(String[] args) {
		long total = 0;
		for (int i = 1; i <= 1000000000; i = i + 1) {
			total = total + i;
		}
		System.out.println(total);
	}

}
