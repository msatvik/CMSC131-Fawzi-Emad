import static org.junit.Assert.*;

import org.junit.Test;


public class PublicTests{
	
	@Test
	public void testBasicConstructorsAndGetters() {
	
		MyDouble a = new MyDouble(5.7), b = new MyDouble(-3.7);
		MyDouble d = new MyDouble(555.729);
		
		ComplexNumber x = new ComplexNumber(a, b);
		assertTrue(x.getReal().compareTo(a) == 0 && 
				x.getImag().compareTo(b) == 0);
		
		ComplexNumber z = new ComplexNumber(d);
		assertTrue(z.getReal().compareTo(d) == 0 && 
				z.getImag().compareTo(new MyDouble(0)) == 0);
	}
	
	@Test
	public void testCopyConstructor() {
		
		MyDouble a = new MyDouble(5.7), b = new MyDouble(-3.7);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(x);
		assertTrue(x != y);     // Check to be sure they are not aliased!
		assertTrue(y.getReal().compareTo(a) == 0 && 
				y.getImag().compareTo(b) == 0);
	}
	
	@Test
	public void testAdd(){
		MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7);
		MyDouble c = new MyDouble(1.0), d = new MyDouble(2.1);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue((x.add(y)).compareTo(new ComplexNumber(new MyDouble(6.7),
				new MyDouble(5.8))) == 0);
		
		a = new MyDouble(0);
		b = new MyDouble(0);
		c = new MyDouble(1.0);
		d = new MyDouble(2.1);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.add(y)).compareTo(new ComplexNumber(new MyDouble(1.0),
				new MyDouble(2.1))) == 0);
		
		a = new MyDouble(-5.7);
		b = new MyDouble(3.7);
		c = new MyDouble(1.0);
		d = new MyDouble(-2.1);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.add(y)).compareTo(new ComplexNumber(new MyDouble(-4.7),
				new MyDouble(1.6))) == 0);
	}
	
	@Test
	public void testSubtract(){
		MyDouble a = new MyDouble(-2), b = new MyDouble(7);
		MyDouble c = new MyDouble(9.0), d = new MyDouble(-4);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue((x.subtract(y)).compareTo(new ComplexNumber(new MyDouble(-11),
				new MyDouble(11))) == 0);
		
		a = new MyDouble(0);
		b = new MyDouble(0);
		c = new MyDouble(1.0);
		d = new MyDouble(2.1);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.subtract(y)).compareTo(new ComplexNumber(new MyDouble(1.0),
				new MyDouble(-2.1))) == 0);
		
		a = new MyDouble(-2);
		b = new MyDouble(-4);
		c = new MyDouble(2);
		d = new MyDouble(4);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.subtract(y)).compareTo(new ComplexNumber(new MyDouble(-4),
				new MyDouble(8.0))) == 0);
	}
	
	@Test
	public void testMult(){
		MyDouble a = new MyDouble(-2), b = new MyDouble(5);
		MyDouble c = new MyDouble(9.0), d = new MyDouble(-4);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue((x.multiply(y)).compareTo(new ComplexNumber(new MyDouble(2),
				new MyDouble(53.0))) == 0);
		
		a = new MyDouble(0);
		b = new MyDouble(0);
		c = new MyDouble(5.6);
		d = new MyDouble(2);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.multiply(y)).compareTo(new ComplexNumber(new MyDouble(0.0), 
				new MyDouble(0))) == 0);
		
		a = new MyDouble(4);
		b = new MyDouble(2);
		c = new MyDouble(3);
		d = new MyDouble(2);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.multiply(y)).compareTo(new ComplexNumber(new MyDouble(8), 
				new MyDouble(14))) == 0);
	}
	
	@Test
	public void testDiv(){
		MyDouble a = new MyDouble(16), b = new MyDouble(-2);
		MyDouble c = new MyDouble(3), d = new MyDouble(-2);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue((x.divide(y)).compareTo(new ComplexNumber(new MyDouble(4), 
				new MyDouble(2))) == 0);
		
		a = new MyDouble(0);
		b = new MyDouble(0);
		c = new MyDouble(5.6);
		d = new MyDouble(2);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.divide(y)).compareTo(new ComplexNumber(new MyDouble(0.0), 
				new MyDouble(0))) == 0);
		
		a = new MyDouble(-8);
		b = new MyDouble(27);
		c = new MyDouble(2);
		d = new MyDouble(3);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue((x.divide(y)).compareTo(new ComplexNumber(new MyDouble(5.0), 
				new MyDouble(6.0))) == 0);
	}
	
	@Test
	public void testEqComp(){
		MyDouble a = new MyDouble(5), b = new MyDouble(12);
		MyDouble c = new MyDouble(3.0), d = new MyDouble(4.0);
		
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue(x.compareTo(y) == 1);
		assertFalse(x.equals(y));
		
		a = new MyDouble(1);
		b = new MyDouble(2);
		c = new MyDouble(3.0);
		d = new MyDouble(4.0);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue(x.compareTo(y) == -1);
		
		a = new MyDouble(4);
		b = new MyDouble(3);
		c = new MyDouble(3.0);
		d = new MyDouble(4.0);
		
		x = new ComplexNumber(a, b);
		y = new ComplexNumber(c, d);
		assertTrue(x.compareTo(y) == 0);
		assertFalse(x.equals(y));
		
		y = new ComplexNumber(d, c);
		assertTrue(x.equals(y));
	}
	
	@Test
	public void testNorm(){
		MyDouble a = new MyDouble(3.0), b = new MyDouble(4.0);
		
		ComplexNumber x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.norm(x).compareTo(new MyDouble(5)) == 0);
		
		a = new MyDouble(5);
		b = new MyDouble(-12);
		
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.norm(x).compareTo(new MyDouble(13)) == 0);
		
		a = new MyDouble(4.0);
		b = new MyDouble(0);
		
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.norm(x).compareTo(new MyDouble(4)) == 0);
	}
	
	@Test
	public void testParse(){
		String complexString = "   -   2.7   +   5.9   i";
		MyDouble a = new MyDouble(-2.7), b = new MyDouble(5.9);
		ComplexNumber x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
		
		complexString = "3.0   - 2.1i";
		a = new MyDouble(3.0);
		b = new MyDouble(-2.1);
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
		
		complexString = "46+0i";
		a = new MyDouble(46.0);
		b = new MyDouble(0);
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
		
		complexString = " - 2+   4.6543i ";
		a = new MyDouble(-2);
		b = new MyDouble(4.6543);
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
		
		complexString = " - 2 -4.6543i ";
		a = new MyDouble(-2);
		b = new MyDouble(-4.6543);
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
		
		complexString = "0 + 0i";
		a = new MyDouble(0);
		b = new MyDouble(0.0);
		x = new ComplexNumber(a, b);
		assertTrue(ComplexNumber.parseComplexNumber(complexString).compareTo(x) == 0);
	}
}
