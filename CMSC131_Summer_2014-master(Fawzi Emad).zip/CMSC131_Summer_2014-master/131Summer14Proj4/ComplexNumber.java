
public class ComplexNumber {
	
	private final MyDouble real;   // To be initialized in constructors
	private final MyDouble imag;   // To be initialized in constructors
	
	
	/* STUDENTS: Put your methods here, as described in the project description.
	 * IMPORTANT:  You may NOT call the toString method for the MyDouble class except
	 * while you are writing the toString method for the Complex class.  You may NOT
	 * call the toString method of the Complex class ANYWHERE.  If you don't adhere
	 * to this rule, you will fail some (or possibly all) release tests. */
	
	/* Constructors */
	public ComplexNumber(MyDouble real, MyDouble imag){
		this.real = real;
		this.imag = imag;
	}
	
	public ComplexNumber(MyDouble real){
		this.real = real;
		this.imag = new MyDouble(0.0);
	}
	
	/* Copy Constructor */
	public ComplexNumber(ComplexNumber complexNumber){
		this.real = complexNumber.getReal();
		this.imag = complexNumber.getImag();
	}
	
	/* Returns the real component */
	public MyDouble getReal(){
		return real;
	}
	
	/* Returns the imaginary component */
	public MyDouble getImag(){
		return imag;
	}
	
	/* Adds this complex number to the parameter complex number*/
	public ComplexNumber add(ComplexNumber complexNumber){
		MyDouble realNum = complexNumber.getReal().add(this.real);
		MyDouble imagNum = complexNumber.getImag().add(this.imag);
		return new ComplexNumber(realNum, imagNum);
	}
	
	/* Subtracts the parameter complex number from this complex number */
	public ComplexNumber subtract(ComplexNumber complexNumber){
		MyDouble realNum = this.real.add(complexNumber.getReal().multiply(new MyDouble(-1)));
		MyDouble imagNum = this.imag.add(complexNumber.getImag().multiply(new MyDouble(-1)));
		return new ComplexNumber(realNum, imagNum);
	}
	
	/* Multiplies this complex number to the parameter complex number */
	public ComplexNumber multiply(ComplexNumber complexNumber){
		MyDouble real1 = this.real.multiply(complexNumber.getReal());
		MyDouble imag1 = this.real.multiply(complexNumber.getImag());
		MyDouble imag2 = this.imag.multiply(complexNumber.getReal());
		MyDouble imag3 = this.imag.multiply(complexNumber.getImag());
		MyDouble real2 = imag3.multiply(new MyDouble(-1));
		
		return new ComplexNumber(real1.add(real2), imag1.add(imag2));
	}
	
	/* Divides this complex number by the parameter complex number */
	public ComplexNumber divide(ComplexNumber complexNumber){
		MyDouble topLeft = this.real.multiply(complexNumber.getReal());
		MyDouble topLeft2 = this.imag.multiply(complexNumber.getImag());
		MyDouble bottomReal = complexNumber.getReal().multiply(complexNumber.getReal());
		MyDouble bottomImag = complexNumber.getImag().multiply(complexNumber.getImag());
		MyDouble bottom = bottomReal.add(bottomImag);
		MyDouble topRight = this.imag.multiply(complexNumber.getReal());
		MyDouble topRight2 = this.real.multiply(complexNumber.getImag());
		
		MyDouble topReal = topLeft.add(topLeft2);
		MyDouble topImag = topRight.subtract(topRight2);
		
		return new ComplexNumber(topReal.divide(bottom), topImag.divide(bottom));
	}
	
	/* Returns true if the parameter complex number equals this complex nmber */
	public boolean equals(ComplexNumber complexNumber){
		return (this.real.equals(complexNumber.getReal()) &&
				this.imag.equals(complexNumber.getImag()));
	}
	
	/* If the norm of this complex number is less than the norm of the parameter
	 * then it returns -1. If the norm of this complex number is greater than the
	 * norm of the parameter then it returns 1. Otherwise, return 0. */
	public int compareTo(ComplexNumber complexNumber){
		int value = norm(this).compareTo(norm(complexNumber));
		
		if (value < 0){
			return -1;
		}else if(value > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
	/* Returns the string representation of the complex number */
	public String toString(){
		if(this.imag.compareTo(new MyDouble(0)) < 0){
			return this.real.toString() + "-" + this.imag.abs().toString() + "i";
		}else{
			return this.real.toString() + "+" + this.imag.toString() + "i";
		}
	}
	
	/* Returns the norm of the parameter. The norm is computed by doing the square root
	 * of the sum of the real component squared plus the imaginary component squared. */
	public static MyDouble norm(ComplexNumber complexNumber){
		MyDouble realSquared = complexNumber.getReal().multiply(complexNumber.getReal());
		MyDouble imagSquared = complexNumber.getImag().multiply(complexNumber.getImag());
		MyDouble realPlusImag = realSquared.add(imagSquared);
		
		return new MyDouble(realPlusImag.sqrt());
	}
	
	/* Returns the complex number form of the string parameter. The string
	 * can have any number of spaces. */
	public static ComplexNumber parseComplexNumber(String complexString){
		complexString = complexString.replaceAll("\\s+", "");
		String realNum, imagNum;
		if (complexString.indexOf('+') != -1){
			int signIndex = complexString.indexOf('+');
			realNum = complexString.substring(0, signIndex);
			imagNum = complexString.substring(signIndex + 1, complexString.length() - 1);
		}else{
			int signIndex = complexString.indexOf('-');
			if (signIndex == 0){
				signIndex = (complexString.substring(1)).indexOf('-') + 1;
			}
			realNum = complexString.substring(0, signIndex);
			imagNum = complexString.substring(signIndex, complexString.length() - 1);
		}
		
		double realNumAsDouble = Double.parseDouble(realNum);
		double imagNumAsDouble = Double.parseDouble(imagNum);
		
		return new ComplexNumber(new MyDouble(realNumAsDouble),
				new MyDouble(imagNumAsDouble));
	}
}
