package poker;
public class PokerHandEvaluator {
	
	public static boolean hasPair(Card[] cards) {
	
		if( cards[0].getValue() == cards[1].getValue() ||
			cards[0].getValue() == cards[2].getValue() ||
			cards[0].getValue() == cards[3].getValue() ||
			cards[0].getValue() == cards[4].getValue()){
			return true;
		} else if(	cards[1].getValue() == cards[2].getValue() ||
					cards[1].getValue() == cards[3].getValue() ||
					cards[1].getValue() == cards[4].getValue()){
			return true;
		} else if(	cards[2].getValue() == cards[3].getValue() ||
					cards[2].getValue() == cards[4].getValue()){
			return true;
		} else if(cards [3].getValue() == cards[4].getValue()){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasTwoPair(Card[] cards) {
		int firstCard = cards[0].getValue(), secondCard = -1, thirdCard = -1;
		int numFirstCards = 1, numSecondCards = 0, numThirdCards = 0;
		
		for (int i = 1; i < 5; i++){
			if (firstCard == cards[i].getValue()){
				numFirstCards++;
			} else if(secondCard == -1){
				secondCard = cards[i].getValue();
				numSecondCards++;
			} else if (secondCard == cards[i].getValue()){
				numSecondCards++;
			} else if(thirdCard == -1){
				thirdCard = cards[i].getValue();
				numThirdCards++;
			} else if (thirdCard == cards[i].getValue()){
				numThirdCards++;
			}
		}
		
		if (numFirstCards >= 2 && numSecondCards >= 2 && firstCard != secondCard){
			return true;
		} else if (numFirstCards >= 2 && numThirdCards >= 2 && firstCard != thirdCard){
			return true;
		} else if (numSecondCards >= 2 && numThirdCards >= 2 && secondCard != thirdCard){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasThreeOfAKind(Card[] cards) {
		int firstCard = cards[0].getValue(), secondCard = -1, thirdCard = -1;
		int numFirstCards = 1, numSecondCards = 0, numThirdCards = 0;
		
		for (int i = 1; i < 5; i++){
			if (firstCard == cards[i].getValue()){
				numFirstCards++;
			} else if(secondCard == -1){
				secondCard = cards[i].getValue();
				numSecondCards++;
			} else if (secondCard == cards[i].getValue()){
				numSecondCards++;
			} else if(thirdCard == -1){
				thirdCard = cards[i].getValue();
				numThirdCards++;
			} else if (thirdCard == cards[i].getValue()){
				numThirdCards++;
			}
		}
		
		if (numFirstCards >=3 || numSecondCards >= 3 || numThirdCards >= 3 ){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasStraight(Card [] cards) {
		Card[] sortedCards = new Card[5];
		sortedCards[0] = cards[0];
		sortedCards[1] = cards[1];
		sortedCards[2] = cards[2];
		sortedCards[3] = cards[3];
		sortedCards[4] = cards[4];
		
		boolean swapped = true;
		
		 while (swapped){
			 swapped= false;
			 for(int j=0;  j < sortedCards.length -1; j++){
				 if (sortedCards[j].getValue() < sortedCards[j+1].getValue()){
					 Card temp = sortedCards[ j ];
					 sortedCards[ j ] = sortedCards[ j+1 ];
					 sortedCards[ j+1 ] = temp;
					 swapped = true;
	              }
			 } 
		 }
		
		if( sortedCards[0].getValue() - 1 == sortedCards[1].getValue() &&
			sortedCards[1].getValue() - 1 == sortedCards[2].getValue() &&
			sortedCards[2].getValue() - 1 == sortedCards[3].getValue() &&
			sortedCards[3].getValue() - 1 == sortedCards[4].getValue()){
			return true;
		} else if(  sortedCards[4].getValue() == 1 &&
					sortedCards[3].getValue() == 10 &&
					sortedCards[2].getValue() == 11 &&
					sortedCards[1].getValue() == 12 &&
					sortedCards[0].getValue() == 13){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasFlush(Card[] cards) {
		if (cards[0].getSuit() == cards[1].getSuit() &&
			cards[0].getSuit() == cards[2].getSuit() &&
			cards[0].getSuit() == cards[3].getSuit() &&
			cards[0].getSuit() == cards[4].getSuit()){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasFullHouse(Card[] cards) {
		int firstCard = cards[0].getValue(), secondCard = -1;
		int numFirstCards = 1, numSecondCards = 0;
		
		for (int i = 1; i < 5; i++){
			if (firstCard == cards[i].getValue()){
				numFirstCards++;
			} else{
				if (secondCard == -1){
					secondCard = cards[i].getValue();
					numSecondCards++;
				} else if (secondCard == cards[i].getValue()){
					numSecondCards++;
				}
			}
		}
		
		if (numFirstCards == 3 && numSecondCards == 2){
			return true;
		} else if (numFirstCards == 2 && numSecondCards == 3){
			return true;
		}
		
		return false;
	}
	
	public static boolean hasFourOfAKind(Card[] cards) {
		int firstCard = cards[0].getValue(), secondCard = -1;
		int numFirstCards = 1, numSecondCards = 0;
		
		for (int i = 1; i < 5; i++){
			if (firstCard == cards[i].getValue()){
				numFirstCards++;
			} else{
				if (secondCard == -1){
					secondCard = cards[i].getValue();
					numSecondCards++;
				} else if (secondCard == cards[i].getValue()){
					numSecondCards++;
				}
			}
		}
		
		if (numFirstCards == 4){
			return true;
		} else if (numSecondCards == 4){
			return true;
		}
		
		return false;
			
	}
	
	public static boolean hasStraightFlush(Card[] cards) {
		if (hasStraight(cards) && hasFlush(cards)){
			return true;
		}
		
		return false;
	}
}

