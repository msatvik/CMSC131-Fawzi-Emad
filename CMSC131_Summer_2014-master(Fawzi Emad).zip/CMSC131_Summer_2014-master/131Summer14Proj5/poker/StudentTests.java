package poker;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTests {

	@Test
	public void testHasPair() {
		Card[] cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(11, 2);
		cards[3] = new Card(1, 0);
		cards[4] = new Card(3, 0);
		
		assertTrue(PokerHandEvaluator.hasPair(cards));
		
		cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(11, 2);
		cards[3] = new Card(10, 1);
		cards[4] = new Card(3, 0);
		
		assertFalse(PokerHandEvaluator.hasPair(cards));
	}
	
	@Test
	public void testHasTwoPair() {
		Card[] cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(3, 0);
		
		assertTrue(PokerHandEvaluator.hasTwoPair(cards));
		
		cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(11, 2);
		cards[3] = new Card(10, 1);
		cards[4] = new Card(3, 0);
		
		assertFalse(PokerHandEvaluator.hasTwoPair(cards));
		
		cards = new Card[5];
		cards[0] = new Card(2, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(10, 1);
		cards[4] = new Card(2, 0);
		
		assertFalse(PokerHandEvaluator.hasTwoPair(cards));
	}
	
	@Test
	public void testHasThreeOfAKind() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(3, 0);
		
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(cards));
		
		cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(10, 1);
		cards[4] = new Card(3, 0);
		
		assertFalse(PokerHandEvaluator.hasThreeOfAKind(cards));
		
		cards = new Card[5];
		cards[0] = new Card(2, 1);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(10, 1);
		cards[4] = new Card(2, 0);
		
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(cards));
	}
	
	@Test
	public void testHasStraight() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 1);
		cards[1] = new Card(3, 3);
		cards[2] = new Card(5, 2);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(4, 0);
		
		assertTrue(PokerHandEvaluator.hasStraight(cards));
		
		cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(13, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(4, 1);
		cards[4] = new Card(3, 0);
		
		assertFalse(PokerHandEvaluator.hasStraight(cards));
		
		cards = new Card[5];
		cards[0] = new Card(5, 1);
		cards[1] = new Card(6, 3);
		cards[2] = new Card(7, 2);
		cards[3] = new Card(3, 1);
		cards[4] = new Card(2, 0);
		
		assertFalse(PokerHandEvaluator.hasStraight(cards));
		
		cards = new Card[5];
		cards[0] = new Card(10, 1);
		cards[1] = new Card(11, 3);
		cards[2] = new Card(12, 2);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(13, 0);
		
		assertTrue(PokerHandEvaluator.hasStraight(cards));
	}
	
	@Test
	public void testHasFlush() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 1);
		cards[1] = new Card(3, 1);
		cards[2] = new Card(5, 1);
		cards[3] = new Card(1, 1);
		cards[4] = new Card(4, 1);
		
		assertTrue(PokerHandEvaluator.hasFlush(cards));
		
		cards = new Card[5];
		cards[0] = new Card(1, 1);
		cards[1] = new Card(13, 3);
		cards[2] = new Card(2, 2);
		cards[3] = new Card(4, 1);
		cards[4] = new Card(3, 0);
		
		assertFalse(PokerHandEvaluator.hasFlush(cards));
	}
	
	@Test
	public void testHasFullHouse() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 0);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(5, 1);
		cards[3] = new Card(5, 2);
		cards[4] = new Card(2, 1);
		
		assertTrue(PokerHandEvaluator.hasFullHouse(cards));
		
		cards = new Card[5];
		cards[0] = new Card(3, 1);
		cards[1] = new Card(3, 3);
		cards[2] = new Card(3, 2);
		cards[3] = new Card(1, 1);
		cards[4] = new Card(12, 0);
		
		assertFalse(PokerHandEvaluator.hasFullHouse(cards));
	}
	
	@Test
	public void testHasFourOfAKind() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 0);
		cards[1] = new Card(2, 3);
		cards[2] = new Card(5, 1);
		cards[3] = new Card(2, 2);
		cards[4] = new Card(2, 1);
		
		assertTrue(PokerHandEvaluator.hasFourOfAKind(cards));
		
		cards = new Card[5];
		cards[0] = new Card(3, 1);
		cards[1] = new Card(3, 3);
		cards[2] = new Card(3, 2);
		cards[3] = new Card(1, 1);
		cards[4] = new Card(12, 0);
		
		assertFalse(PokerHandEvaluator.hasFourOfAKind(cards));
	}
	
	@Test
	public void testHasStraightFlush() {
		Card[] cards = new Card[5];
		cards[0] = new Card(2, 0);
		cards[1] = new Card(3, 0);
		cards[2] = new Card(5, 0);
		cards[3] = new Card(4, 0);
		cards[4] = new Card(1, 0);
		
		assertTrue(PokerHandEvaluator.hasStraightFlush(cards));
		
		cards = new Card[5];
		cards[0] = new Card(2, 0);
		cards[1] = new Card(3, 1);
		cards[2] = new Card(5, 0);
		cards[3] = new Card(4, 0);
		cards[4] = new Card(1, 0);
		
		assertFalse(PokerHandEvaluator.hasStraightFlush(cards));
		
		cards = new Card[5];
		cards[0] = new Card(2, 0);
		cards[1] = new Card(3, 0);
		cards[2] = new Card(13, 0);
		cards[3] = new Card(4, 0);
		cards[4] = new Card(1, 0);
		
		assertFalse(PokerHandEvaluator.hasStraightFlush(cards));
		
		cards = new Card[5];
		cards[0] = new Card(10, 1);
		cards[1] = new Card(11, 3);
		cards[2] = new Card(12, 2);
		cards[3] = new Card(1, 3);
		cards[4] = new Card(13, 0);
		
		assertFalse(PokerHandEvaluator.hasStraightFlush(cards));
		
		cards = new Card[5];
		cards[0] = new Card(10, 0);
		cards[1] = new Card(11, 0);
		cards[2] = new Card(12, 0);
		cards[3] = new Card(1, 0);
		cards[4] = new Card(13, 0);
		
		assertTrue(PokerHandEvaluator.hasStraightFlush(cards));
	}

}
