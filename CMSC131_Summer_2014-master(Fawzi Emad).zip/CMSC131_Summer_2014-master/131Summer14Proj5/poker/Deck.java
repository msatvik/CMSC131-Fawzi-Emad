package poker;

public class Deck {


	private Card[] cards;

	private static final int NUMCARDS    = 52;             //Total Number of cards in a deck
	private static final int SPADES_SUIT = 0;            





	public Deck() {

		cards = new Card[NUMCARDS];          //initializes array of deck of cards

		int i =0;

		/*FOR LOOP THAT STARTS AT SUIT OF SPADE AND ENDS
		 *AT THE KING OF DIAMONDS*/
		for(int suit = SPADES_SUIT; suit<=3 ; suit++){
			for(int rank = 1; rank<=13; rank++){
				cards[i++] = new Card(rank, suit);
			}

		}
	}
	/*METHOD SETS OTHER TO CARDS*/
	public Deck(Deck other) {

		cards = other.cards;
	}

	/*METHOD RETURNS POSITION OF CARD*/
	public Card getCardAt(int position) {
		return cards[position];
	}

	/*METHOD RETURN LENGTH OF CARDS*/
	public int getNumCards() {
		return cards.length;
	}
	
	
	public void shuffle() {
		int lengthOfTopPacket, lengthOfBottomPacket = cards.length / 2;

		if (cards.length % 2 == 0){
			lengthOfTopPacket = cards.length / 2;
		} else{
			lengthOfTopPacket = (cards.length / 2) + 1;

		}

		Card[] bottomPacket = new Card[lengthOfBottomPacket];
		Card[] topPacket = new Card[lengthOfTopPacket];
		int elem = 0;

		for(int i=0; i < cards.length; i++){
			if (i < lengthOfTopPacket){
				topPacket[i] = cards[i];
			} else {
				bottomPacket[elem] = cards[i];
				elem++;
			}
		}

		int elemInHalves = 0;

		for(int i=0; i<cards.length; i++){
			if (i % 2 == 0){
				cards[i] = topPacket[elemInHalves];
			} else {
				cards[i] = bottomPacket[elemInHalves];
				elemInHalves++;
			}
		}
	}

	public void cut(int position) {

		Card[] firstHalf = new Card[position+1];
		Card[] secondHalf = new Card[(cards.length) - (position)];

		for(int i=0; i<=position; i++){
			firstHalf[i] = cards[i];
		}
		int k=0;
		for(int j=position; j<cards.length; j++){
			secondHalf[k]= cards[j];
			k++;
		}

		int firstHalfIndex = 0;
		for(int rank= 0; rank<cards.length; rank++){
			if(rank < secondHalf.length){
				cards[rank] = secondHalf[rank];
			}else{
				cards[rank] = firstHalf[firstHalfIndex];
				firstHalfIndex++;
			}
		}
	}

	public Card[] deal(int numCards) {
		
		Card[] smaller = new Card[cards.length - numCards];
		Card[] cardsDelt = new Card[numCards];
		int smallerIndex = 0;
		
		for(int i=0; i<numCards; i++){
			cardsDelt[i] = cards[i];
		}
		
		for(int rank=numCards; rank<cards.length; rank++){
			smaller[smallerIndex] = cards[rank];
			smallerIndex++;
		}
		
		cards = smaller;
		
		return cardsDelt;
	}

}
