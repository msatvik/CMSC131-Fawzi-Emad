package pirateStuff;

public class Pirate {
	public int age;
	public double weight;
	public EyePatch patch;
	public Parrot bird;
	
	public Pirate(Pirate other) {
		age = other.age;
		weight = other.weight;
		patch = other.patch;
		bird = other.bird;
	}
	
	public Parrot getBird() {
		return bird;
	}
	
	public Pirate(Parrot birdIn) {
		age = 25;
		weight = 185;
		patch = new EyePatch();
		bird = birdIn;
	}
	
	// imagine lots more stuff...
	
}
