package pirateStuff;

public class EyePatch {

	public EyePatch() {
		
	}
	
	public EyePatch(EyePatch e) {
		
	}
}
