package pirateStuff;

public class Parrot {

	public Parrot() {
		
	}

	public Parrot(Parrot p) {
		
	}
}
