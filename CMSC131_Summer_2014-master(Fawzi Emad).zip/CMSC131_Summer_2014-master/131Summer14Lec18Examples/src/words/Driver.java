package words;

public class Driver {

	public static void main(String[] args) {
		Paragraph p = new Paragraph();
		System.out.println(p);

	}

}
