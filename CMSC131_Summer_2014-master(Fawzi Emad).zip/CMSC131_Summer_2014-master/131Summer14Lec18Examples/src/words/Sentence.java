package words;
import java.util.Random;

public class Sentence {

	private Word[] words;
	
	public Sentence() {
		Random r = new Random();
		int length = r.nextInt(12) + 3;
		words = new Word[length];
		for (int i = 0; i < length; i++) {
			words[i] = new Word();
		}
	}
	
	public String toString() {
		StringBuffer answer = new StringBuffer(words[0].toString());
		for (int i = 1; i < words.length; i++) {
			answer.append(" ");
			answer.append(words[i]);
		}
		answer.append(".");
		return answer.toString();
	}
}
