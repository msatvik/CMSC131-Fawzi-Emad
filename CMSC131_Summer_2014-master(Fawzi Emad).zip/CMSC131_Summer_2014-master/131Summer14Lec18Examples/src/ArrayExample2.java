
public class ArrayExample2 {

	public static void main(String[] args) {
		int [] numArr = new int[100];
		
		for (int currPos = 1; currPos <= numArr.length; currPos++) {    // Doh!
			numArr[currPos] = 24;
			System.out.println("put 24 into position "+currPos);
		}

	}

}
