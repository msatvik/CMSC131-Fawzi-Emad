
public class ArrayExample4 {

	public static void triple(int y) {
		y *= 3;
	}
	
	public static void triple(int[] a) {
		for (int ind = 0; ind < a.length; ind++) {
			a[ind] *= 3;
		}
	}
	
	public static void main(String[] args) {
		int y = 5;
		int[] a = new int[100];
		
		for (int ind = 0; ind < 100; ind++){
			a[ind] = 5;
		}
		triple(y);
		triple(a);
		
		System.out.println("After triple, y is " + y);
		System.out.println("After triple, a[7] is " + a[7]);
		
		triple(a[7]);
		System.out.println("After triple, a[7] is " + a[7]);
		
	}

}
