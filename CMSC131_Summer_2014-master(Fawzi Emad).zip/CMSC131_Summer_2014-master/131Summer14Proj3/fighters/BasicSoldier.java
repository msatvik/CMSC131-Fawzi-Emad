package fighters;

import framework.BattleField;
import framework.Random131;

public class BasicSoldier {

	/*FINAL STATIC CONSTANTS*/
	public final static int INITIAL_HEALTH = 4; //initial health of soldier and or fully recovered health
	public final static int ARMOR = 2;          //initial armor of soldier (defense level)
	public final static int STRENGTH = 90;       //initial value of strength and or damaged done to enemy
	public final static int SKILL = 4;          //likelyhood of striking an enemy during attack
	public final static int UP = 0;              //up
	public final static int RIGHT = 1;           //right
	public final static int DOWN = 2;            //down
	public final static int LEFT = 3;            //left
	public final static int UP_AND_RIGHT = 4;    //up and right
	public final static int DOWN_AND_RIGHT = 5;  //down and right
	public final static int DOWN_AND_LEFT = 6;   //down and left
	public final static int UP_AND_LEFT = 7;     //up and left
	public final static int NEUTRAL = -1;        //neutral

	/*INSTANCE VARIABLES*/
	public final BattleField battleField;        //battlefield where soldier fights
	public int row, col;                         //current location of this soldier within the battlefield
	public int health;							 //current health-level of soldier
	public final int team;                       //indicates which team soldier is fighting on

	/*CONSTRUCTORS*/
	public BasicSoldier(BattleField battleFieldIn, int teamIn, int rowIn, int colIn){

		battleField = battleFieldIn;             //sets battleFieldIn Object to the final battleField
		team = teamIn;                           //sets teamIn to team
		row = rowIn;                             //sets rowIn to row
		col = colIn;        					 //sets colIn to col
		health = INITIAL_HEALTH;                 //initializes health to the final constant to initial health to 10 
	}

	/*INSTANCE METHODS BEGIN:

	  METHOD RETURN TRUE IF IT IS POSSIBLE FOR THE SOLDIER TO MOVE,
	  OTHERWISE IT WILL RETURN FALSE*/
	public boolean canMove(){

		/*IF STATEMENT THAT RETURNS TRUE IF SOLDIER CAN MOVE, OTHERWISE FALSE*/
		if((battleField.get(row-1, col) == battleField.EMPTY) ||    //soldier Moving UP
				(battleField.get(row, col+1) == battleField.EMPTY)||    //Soldier Moving Right
				(battleField.get(row, col-1) == battleField.EMPTY)||    //Soldier Moving Left
				(battleField.get(row+1, col) == battleField.EMPTY)){    //Soldier Moving Down
			return true;
		}else{
			return false;
		}
	}

	/*METHOD RETURN NUMBER OF ENEMIES IN BATTLEFIELD*/
	public int numberOfEnemiesRemaining(){

		int totalNumberOfEnemies = 0;  //storage for the Total Number Of Enemies 
		int enemy;

		/*IF STATEMENT ASSIGNING ENEMY TO RED TEAM IF
		 *TEAM CHOSEN EQUALS BLUE */
		if(team == battleField.BLUE_TEAM){                        //if team is equal to Blue_Team which holds a value of 1 
			enemy = battleField.RED_TEAM;                         //sets enemy to Red team which holds a value of 0

			/*NESTED FOR LOOP CHECKING TO SEE WHERE THE ENEMY IS*/	
			for(int rowOne=0; rowOne<battleField.getRows();rowOne++){        
				for(int colOne=0;colOne<battleField.getCols(); colOne++){

					/*IF STATEMENT INSIDE FOR LOOP TO GET
					 *WHATEVER IS AT THE CURRENT LOCATION TO GET
					 *THE ENEMY COUNT */
					if(battleField.get(rowOne, colOne) == enemy){
						totalNumberOfEnemies += 1;                //adds one to the enemy count
					}
				}
			}


		}else if(team == battleField.RED_TEAM){
			enemy = battleField.BLUE_TEAM;

			/*NESTED FOR LOOP CHECKING TO SEE WHERE THE ENEMY IS*/
			for(int rowTwo=0; rowTwo<battleField.getRows();rowTwo++){
				for(int colTwo=0;colTwo<battleField.getCols();colTwo++){

					/*IF STATEMENT INSIDE FOR LOOP TO GET
					 *WHATEVER IS AT THE CURRENT LOCATION TO GET
					 *THE ENEMY COUNT */
					if(battleField.get(rowTwo, colTwo) == enemy){
						totalNumberOfEnemies += 1;                //adds one to the enemy count
					}
				}
			}

		}

		return totalNumberOfEnemies;                             //returns total number of enemies 

	}

	/*METHOD CALCULATED THE NUMBER OF MOVES IT WILL TAKE 
	 * TO REACH DESTINATION SPECIFIED BY PARAMETER*/
	public int getDistance(int destinationRow, int destinationCol){

		int totalDistance = 0;


		if(row < destinationRow){
			totalDistance += destinationRow - row;
		}else{
			totalDistance += row - destinationRow;
		}

		if(col < destinationCol){
			totalDistance += destinationCol - col;
		}else{
			totalDistance += col - destinationCol;
		}

		return totalDistance;


	}

	/*METHOD DETERMINES WHICH DIRECTION SOLDIER WOULD HAVE TO GO */
	public int getDirection(int destinationRow, int destinationCol){

		if(destinationRow > row && destinationCol == col){
			return DOWN;
		}else if(destinationRow < row && destinationCol == col){
			return UP;
		}else if(destinationCol < col && destinationRow == row){
			return LEFT;
		}else if(destinationCol > col && destinationRow == row){
			return RIGHT;
		}else if(destinationRow < row && destinationCol > col){
			return UP_AND_RIGHT;
		}else if(destinationRow > row && destinationCol > col){
			return DOWN_AND_RIGHT;
		}else if(destinationRow > row && destinationCol < col){
			return DOWN_AND_LEFT;
		}else if(destinationRow < row && destinationCol < col){
			return UP_AND_LEFT;
		}else{
			return NEUTRAL;
		}

	}

	/*METHOD RETURNS THE DIRECTION OF NEAREST TEAMMATE*/
	public int getDirectionOfNearestFriend(){

		int closestRow = row, closestCol = col, closestFriend = -1;

		for(int rowOne = 0; rowOne<battleField.getRows(); rowOne++){
			for(int colOne = 0; colOne<battleField.getCols(); colOne++){

				if( battleField.get(rowOne, colOne) == team){
					int distance = this.getDistance(rowOne, colOne);

					if((distance != 0) && (distance < closestFriend || closestFriend == -1)){
						closestRow = rowOne;
						closestCol = colOne;
						closestFriend = distance;
					}
				}
			}
		}
		return this.getDirection(closestRow, closestCol);
	}

	/*METHOD COUNTS THE NUMBER OF TEAMMATES WHOSE DISTANCE FROM
	 *SOLDIER IS LESS THAN OR EQUAL TO THE SPECIFIED RADIUS*/
	public int countNearbyFriends(int radius){

		int totalTeammate = 0;

		for(int rowOne = 0; rowOne<battleField.getRows(); rowOne++){
			for(int colOne = 0; colOne<battleField.getCols(); colOne++){

				if( battleField.get(rowOne, colOne) == team){
					int distance = this.getDistance(rowOne, colOne);

					if((distance != 0) && (distance <= radius)){
						totalTeammate += 1;
					}
				}
			}
		}
		return totalTeammate;
	}

	/*METHOD RETURNS THE DIRECTION OF NEAREST ENEMY
	  WHOSE DISTANCE FROM CURRENT SOLDIER IS LESS THAN OR
	  EQUAL TO THE GIVEN RADIUS*/
	public int getDirectionOfNearestEnemy(int radius){

		int closestRow = row, closestCol = col, closestEnemy = -1, enemy;

		if(team == battleField.RED_TEAM){
			enemy = battleField.BLUE_TEAM;
		}else{
			enemy = battleField.RED_TEAM;
		}

		for(int rowOne = 0; rowOne<battleField.getRows(); rowOne++){
			for(int colOne = 0; colOne<battleField.getCols(); colOne++){

				if(battleField.get(rowOne, colOne) == enemy){
					int distance = this.getDistance(rowOne, colOne);

					if((distance <= radius) && (distance < closestEnemy|| closestEnemy == -1)){
						closestRow = rowOne;
						closestCol = colOne;
						closestEnemy = distance;
					}
				}
			}
		}
		return this.getDirection(closestRow, closestCol);
	}

	/*METHOD THAT WILL BE CALLED BY THE FRAMEWORK*/
	public void performMyTurn(){

		int enemy;

		if(team == battleField.RED_TEAM){
			enemy = battleField.BLUE_TEAM;
		}else{
			enemy = battleField.RED_TEAM;
		}

		if(battleField.get(row,col-1)==enemy){          //left
			battleField.attack(row, col-1);
		}else if(battleField.get(row+1, col)==enemy){   //Down
			battleField.attack(row+1, col);
		}else if(battleField.get(row, col+1)==enemy){   //right
			battleField.attack(row, col+1);             
		}else if(battleField.get(row-1, col)==enemy){   //up
			battleField.attack(row-1, col);
		}else if(battleField.get(row,col-1)==battleField.EMPTY){    //left
			col = col-1;
		}else if(battleField.get(row+1, col)==battleField.EMPTY){   //Down
			row = row+1;
		}else if(battleField.get(row, col+1)==battleField.EMPTY){   //right
			col = col+1;           
		}else if(battleField.get(row-1, col)==battleField.EMPTY){   //up
			row = row-1;
		}
	}
}


