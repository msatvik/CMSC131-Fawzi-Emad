import java.util.*;


public class VitalStats 
{
	public static void main(String[] args)
	{
		String name;
		int age;
		double shoeSize, gpa;
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter name: ");
		name = input.nextLine();
		System.out.print("Please enter Age: ");
		age = input.nextInt();
		System.out.print("Please enter shoe size :");
		shoeSize = input.nextDouble();
		System.out.print("Please enter GPA");
		gpa = input.nextDouble();
		
		System.out.println();
		System.out.println("My name is " + name + " and i was born in San Diego. ");
		System.out.println("My current age is " + age + ", my shoe size is " + shoeSize + " and my GPA is "+gpa);
		
		
	}

}
