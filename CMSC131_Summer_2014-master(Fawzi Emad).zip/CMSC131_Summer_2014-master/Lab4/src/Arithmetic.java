import java.util.*;

public class Arithmetic 
{
	public static void main(String []args)
	{
		/*
		int product, quotient, sum, difference;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter an integer: ");
		int a = input.nextInt();
		System.out.print("Please enter another integer: ");
		int b = input.nextInt();
		
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		
		product = a * b;
		quotient = a / b;
		sum = a + b;
		difference = a - b;
		
		System.out.println(a + " * " + b + " = " + product);
		System.out.println(a + " / " + b + " = " + quotient);
		System.out.println(a + " + " + b + " = " + sum);
		System.out.println(a + " - " + b + " = " + difference);
		*/
		
		// #1 when the second number is zero, we get an airithmetic exception
		
		double product, quotient, sum, difference;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter an integer: ");
		double a = input.nextInt();
		System.out.print("Please enter another integer: ");
		double b = input.nextInt();
		
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		
		product = a * b;
		quotient = a / b;
		sum = a + b;
		difference = a - b;
		
		System.out.println(a + " * " + b + " = " + product);
		System.out.println(a + " / " + b + " = " + quotient);
		System.out.println(a + " + " + b + " = " + sum);
		System.out.println(a + " - " + b + " = " + difference);
		
		//#2 everything works, no exceptions are thrown. 
		
	}

}
