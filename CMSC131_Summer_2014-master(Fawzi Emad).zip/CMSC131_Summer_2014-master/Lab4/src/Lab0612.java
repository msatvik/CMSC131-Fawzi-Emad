import java.util.*;


public class Lab0612 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name, favoriteClass;
		int age, ageInMonths, monthSinceBirthday;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter name: ");
		name = input.nextLine();
		System.out.print("Please enter age: ");
		age = input.nextInt();
		System.out.print("How many months since last birthday: ");
		monthSinceBirthday = input.nextInt();
		input.nextLine();
		System.out.print("what is your favorite class: ");
		favoriteClass = input.nextLine();
		
		ageInMonths = age * 12 + monthSinceBirthday;
		
		if (ageInMonths >= 900)
		{
			System.out.println("Hello " + name +" you are quite old. Your age is "+ageInMonths+" months");
		}else if (ageInMonths <= 120){
			System.out.println("Hello " + name +", you are quite young. your age is "+ageInMonths);
		}else{
			System.out.println("Hello "+name+". Your age is "+ageInMonths+" months");
		}
		
		//System.out.println("Hello " + name +" your age in months in "+ageInMonths);
		System.out.println("your favorite class "+favoriteClass+ " is awesome");
		

	}

}
