

public class ForEachWith2DimensionalArray {

	public static void main(String[] args) {
		int[][] raggedArr = 
				{{91,90},
				{22,24,26,20,28},
				{10,13,17,15,12,19,18,11}};

		for (int[] row : raggedArr){
			for (int value : row){
				System.out.print(value + " ");
			}
			System.out.println();
		}
	
	}
}
