
import java.util.ArrayList;

public class DoNotTryRemoveInsideForEachLoop {

	public static void main(String[] args) {
		
		ArrayList<String> a1 = new ArrayList<String>();
		a1.add("cat");
		a1.add("dog");
		a1.add("bird");
		a1.add("ox");
		a1.add("tiger");
		a1.add("ostrich");
	
		System.out.println("removing short ones");
		/*for (String s : a1) {
			if (s.length() < 4) {
				a1.remove(s);
			}
		}*/
		
		System.out.println("after remove: " + a1);
	}
}
