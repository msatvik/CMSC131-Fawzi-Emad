
import java.util.Stack;
import java.util.ArrayList;



public class ForEachExample {

	public static void main(String[] args) {
		int[] a = {7, 9, 11};
		
		for (int j = 0 ; j < a.length; j++){
			System.out.println(a[j]);
		}
		
		for (int i : a) {
			System.out.println(i);
		}
		
		Cat[] catList = new Cat[5];
		catList[0] = new Cat("Fluffy");
		catList[1] = new Cat("Elvis");
		catList[2] = new Cat("Dante");
		catList[3] = new Cat("Benny");
		catList[4] = new Cat("Alice");
		for (Cat c :catList){
			System.out.println(c);
		}

		Stack<String> stack = new Stack<String>();
		stack.push("cat");
		stack.push("dog");
		stack.push("antelope");
		for (String s : stack) {
			System.out.println(s);
		}

		ArrayList<Student> students = new ArrayList<Student>();
		students.add(new Student("Joe", 12345));
		students.add(new Student("Fred", 27272));
		students.add(new Student("Cindy", 27272));
		for (Student s : students) {
			System.out.println(s);
		}
	}

}
