
public class Computer {
	private long clockSpeed;  
	private String manufacturer;
	

	/* Here will illustrate using this as part of a common style for
	 * declaring parameters to a constructor with names that match
	 * the instance variables.
	 */
	public Computer(String manufacturer, long clockSpeed) {
		this.manufacturer = manufacturer;
		this.clockSpeed = clockSpeed;
	}
	
	/* Here we illustrate using "this" in a way that is not
	 * wrong, but not necessary.
	 */
	private String solveProblem(String problem) {
		if (problem.length() > 20)  {
			return "This problem is too complex for a " + this.manufacturer +
			       " computer running at just " + this.clockSpeed + " ticks per second.";
		} else {
			return "The answer is 42.";
		}
	}
	
	public void frustrate(Student s) {
		System.out.println("Sorry, " + s.name + ", I will never cooperate!");
	}
	
	public static void main(String[] args) {
		Computer c = new Computer("Dell", 3000000000L);
		
		System.out.println(c.solveProblem("What is the meaning of life, the Universe and Everything?"));
		
	}

}
