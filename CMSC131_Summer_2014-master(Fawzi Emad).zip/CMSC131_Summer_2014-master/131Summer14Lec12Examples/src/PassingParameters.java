
public class PassingParameters {
	
	public static void copyName(int numCopies, Student victim) {
		String original = victim.name;
		while (--numCopies > 0) {
			 victim.name += original;
		}
	}
	
	public static void main(String[] args) {
		Student a = new Student("Bob", 12345, 3);
		int num = 3;
		
		copyName(num, a);
		
		System.out.println(a);
		System.out.println(num);
	}
	
}
