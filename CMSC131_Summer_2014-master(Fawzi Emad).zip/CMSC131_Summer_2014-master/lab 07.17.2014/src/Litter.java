import java.util.Arrays;

public class Litter {
	
	private Puppy[] grouping;
	
	public Litter(){
		grouping = new Puppy[0];
	}
	
	public Puppy[] geShallowCopy(Puppy[] original){
		Puppy[] shallowCopy = new Puppy[original.length];
		
		for(int index=0; index< original.length; index++){
			shallowCopy[index] = original[index]; 
		}
		return shallowCopy;
	}
	
	public Puppy[] getDeepCopy(Puppy[] original){
   Puppy[] deepCopy = new Puppy[original.length];
		
		for(int index=0; index< original.length; index++){
			deepCopy[index] = new Puppy(original[index]); 
		}
		return deepCopy;
	}
	
	public Puppy[] getReferenceCopy(Puppy[] original){
		Puppy[] referenceCopy = original;
		return original;
	}
	
	
}
