
public class Puppy {
	
	private String puppyName;
	private int puppyPaws;
	
	public Puppy(String nameIn, int puppyPaws){
		puppyName = nameIn;
		this.puppyPaws = puppyPaws; 
	}
	public compareTo(Puppy other){
		
		if(puppyName.length() > other.puppyName)
		
		
		
	}
	
	public Puppy(Puppy original){
		
		puppyName = original.puppyName;
		puppyPaws = original.puppyPaws;
		
	}

}
