package foodManagement;

/**
 * A SortedListOfImmutables represents a sorted collection of immutable objects 
 * that implement the Listable interface.  
 * 
 * An array of references to Listable objects is used internally to represent 
 * the list.  
 * 
 * The items in the list are always kept in alphabetical order based on the 
 * names of the items.  When a new item is added into the list, it is inserted 
 * into the correct position so that the list stays ordered alphabetically
 * by name.
 */
public class SortedListOfImmutables {

	/*
	 * STUDENTS:  You may NOT add any other instance variables to this class!
	 */
	private Listable[] items;

	/**
	 * This constructor creates an empty list by creating an internal array
	 * of size 0.  (Note that this is NOT the same thing as setting the internal
	 * instance variable to null.) 
	 */
	public SortedListOfImmutables() {
		items = new Listable[0];
	}

	/**
	 *  Copy constructor.  The current object will become a copy of the
	 *  list that the parameter refers to.  
	 *  
	 *  The copy must be made in such a way that future changes to
	 *  either of these two lists will not affect the other. In other words, 
	 *  after this constructor runs, adding or removing things from one of 
	 *  the lists must not have any effect on the other list.
	 *  
	 *  @param other the list that is to be copied
	 */
	public SortedListOfImmutables(SortedListOfImmutables other) {
		items = new Listable[other.getSize()];

		for(int index=0; index<other.getSize(); index++){
			items[index] = other.get(index);
		}
	}

	/**
	 * Returns the number of items in the list.
	 * @return number of items in the list
	 */
	public int getSize() {
		return items.length;
	}

	/**
	 * Returns a reference to the item in the ith position in the list.  (Indexing
	 * is 0-based, so the first element is element 0).
	 * 
	 * @param i index of item requested
	 * @return reference to the ith item in the list
	 */
	public Listable get(int i) {
		return items[i];
	}

	/**
	 * Adds an item to the list.  This method assumes that the list is already
	 * sorted in alphabetical order based on the names of the items in the list.
	 * 
	 * The new item will be inserted into the list in the appropriate place so
	 * that the list will remain alphabetized by names.
	 * 
	 * In order to accomodate the new item, the internal array must be re-sized 
	 * so that it is one unit larger than it was before the call to this method.
	 *  
	 * @param itemToAdd refers to a Listable item to be added to this list
	 */
	public void add(Listable itemToAdd) {

		Listable[] temporaryItems = new Listable[items.length+1];
		boolean taken=false;
		for(int index=0;index<items.length;index++){
			temporaryItems[index]=items[index];
		}
		if(items.length==0){
			temporaryItems[0]=itemToAdd;
		}else{
			for(int index=0; index<items.length;index++){
				if(itemToAdd.getName().compareTo(items[index].getName())<0 && taken==false){

					temporaryItems[index]=itemToAdd;
					for(int i=index+1;i<temporaryItems.length;i++){
						temporaryItems[i]=items[i-1];
					}
					taken = true;
				}
			}
			if(taken==false){
				temporaryItems[temporaryItems.length-1]=itemToAdd;
			}
		}

		items = new Listable[temporaryItems.length];
		for(int j=0;j<temporaryItems.length;j++){
			items[j]=temporaryItems[j];
		}

		/*If there are items already in the items array, */

		/*
		 * if(items.length>0){

			//holds the new "items' List
			Listable[] tempArray = new Listable[items.length + 1];
			boolean itemAdded = false;
			int itemsIndex =0;

			/*copies items to a tempArray, adding itemToAdd in the appropriate spot*/ 
		/*for(int index=0; index<tempArray.length; index++){

				if(itemsIndex == items.length ||
						(!itemAdded && 
								itemToAdd.getName().compareTo(items[itemsIndex].getName()) < 0)){

					tempArray[index] = itemToAdd;
					itemAdded = true;
				}else{
					tempArray[index] = items[itemsIndex];
					itemsIndex++;
				}
			}

			//makes the new items array and copies everything into it
			items = new Listable[tempArray.length];

			for(int index=0;index<tempArray.length; index++){
				items[index] = tempArray[index];
			}
		}else{
			items = new Listable[1];
			items[0] = itemToAdd;
		}*/

	}

	/**
	 * Adds an entire list of items to the current list, maintaining the 
	 * alphabetical ordering of the list by the names of the items.
	 * 
	 * @param listToAdd a list of items that are to be added to the current object
	 */
	public void add(SortedListOfImmutables listToAdd) {

		for(int i=0;i<listToAdd.items.length;i++){
			this.add(listToAdd.items[i]);
		}



		/*
		if(items.length > 0){
			//holds the new 'items' list
			Listable[] tempArray = new Listable[items.length + listToAdd.getSize()];

			//Indexes for each array to keep track of where its at in the array
			int tempArrayIndex = 0, listToAddIndex = 0, itemsIndex = 0;

			while(itemsIndex < items.length){
				/*If the next item in ListToAdd is supposed to be added in at that spot,
		 * add it, then increase ListToAddIndex by 1 so that we can get the next 
		 * item in the list to compare */
		/*if(listToAddIndex < listToAdd.getSize() &&
						listToAdd.get(listToAddIndex).getName().compareTo(items[itemsIndex].getName()) < 0){
					tempArray[tempArrayIndex] = listToAdd.get(listToAddIndex);
					listToAddIndex++;
				}
				tempArrayIndex++;
			}

			//makes the new items array and copies everything into it
			items = new Listable[tempArray.length];

			for(int index = 0; index< tempArray.length;index++){
				items[index] = tempArray[index];
			}
		}else{
			items = new Listable[listToAdd.getSize()];
			for(int index = 0; index < listToAdd.getSize(); index++){
				items[index] = listToAdd.get(index);
			}
		}
		 */
	}

	/**
	 * Removes an item from the list.
	 * 
	 * If the list contains the same item that the parameter refers to, it will be 
	 * removed from the list.  
	 * 
	 * If the item appears in the list more than once, just one instance will be
	 * removed.
	 * 
	 * If the item does not appear on the list, then this method does nothing.
	 * 
	 * @param itemToRemove refers to the item that is to be removed from the list
	 */
	public void remove(Listable itemToRemove) {

		boolean reSizing=false;
		for(int i=0;i<items.length;i++){
			if(items[i].getName().equals(itemToRemove.getName())){
				reSizing=true;
				break;
			}
		}

		if(reSizing==true){
			Listable[] temporaryItems = new Listable[items.length-1];
			int y=0;
			boolean alreadyRemoved=false;
			for(int j=0;j<items.length;j++){
				if(items[j].getName().equals(itemToRemove.getName())&& alreadyRemoved==false){
					alreadyRemoved=true;
					continue;
				}else{
					temporaryItems[y]=items[j];
					y++;
				}
			}
			items = new Listable[temporaryItems.length];
			for(int k=0;k<items.length;k++){
				items[k]=temporaryItems[k];
			}
		}


		//if(items.length > 0){
		//Holds the new 'items' list
		//Listable[] tempArray = new Listable[items.length -1];
		//int tempArrayIndex =0;
		//boolean removed = false;
		/*copies items to tempArray, removing itemToRemove when found first*/
		/*for(int index =0; index < items.length; index++){
				/*Adds the item at index to the tempArray list if the item isn't
		 *itemToRemove or if it is the item it has already been removed
		 *once
		 */
		/*	if(tempArrayIndex == tempArray.length ||
						(items[index].getName().equals(itemToRemove.getName()) && !removed)){
					removed= true;

				}else{
					tempArray[tempArrayIndex] = items[index];
					tempArrayIndex++;
				}
			}
			//Makes the new items array and copies everything into it
			items = new Listable[tempArray.length];

			for(int index=0; index<items.length; index++){
				items[index] = tempArray[index];
			}
		}*/
	}

	/**
	 * Removes an entire list of items from the current list.  Any items in the
	 * parameter that appear in the current list are removed; any items in the
	 * parameter that do not appear in the current list are ignored.
	 * 
	 * @param listToRemove list of items that are to be removed from this list
	 */
	public void remove(SortedListOfImmutables listToRemove) {

		for(int i=0;i<listToRemove.getSize();i++){
			this.remove(listToRemove.get(i));
		}

		/*Only checks for removal of items if the items array has stuff in it*/
		//if(items.length >0){
		//holds the new 'items' list
		//Listable[] tempArray = new Listable[items.length - listToRemove.getSize()];
		//Indexes for reach array to keep track of where its at in the array
		//int tempArrayIndex = 0, listToRemoveIndex =0, itemsIndex =0;

		//while(itemsIndex < items.length){
		/*If the next item in the listToRemove is farther down alphabetically
		 * then the item in items then adds the item to tempArray and moves
		 * tempArray and items index down one to get ready for the next element*/
		//if(listToRemove.get(listToRemoveIndex).getName().compareTo(items[itemsIndex].getName()) > 0){
		//	tempArray[tempArrayIndex] = items[itemsIndex++];
		//tempArrayIndex++;
		//itemsIndex++;

		/*if the next item in listToRemove is earlier alphabetically then the
		 *item in items, then moves the listToRemove index up one, so we can
		 *compare the next item */	
		//}else if(listToRemove.get(listToRemoveIndex).getName().compareTo(items[itemsIndex].getName()) < 0){
		//		listToRemoveIndex++;

		/*if the next item in listToRemove is the same as the item in items, 
		 *then do nothing except move the items index up one, so we can
		 *compare the next item*/	
		//	}else{
		//		itemsIndex++;
		//	}

		//	}
		//	//makes the new items array and copies everything into it
		//			items = new Listable[tempArray.length];

		//for(int index =0; index < tempArray.length; index++){
		//items[index] = tempArray[index];
		//}
		//}
	}

	/**
	 * Returns the sum of the wholesale costs of all items in the list.
	 * 
	 * @return sum of the wholesale costs of all items in the list
	 */
	public int getWholesaleCost() {
		int totalCost =0; 

		//gets the wholesale cost at each item and adds it to totalCost
		for(int index=0; index<items.length; index++){
			totalCost += items[index].getWholesaleCost();
		}
		return totalCost;
	}

	/**
	 * Returns the sum of the retail values of all items in the list.
	 * 
	 * @return sum of the retail values of all items in the list
	 */
	public int getRetailValue() {

		int totalValue=0;
		//gets the retail value at each item and adds it to totalValue
		for(int index =0; index< items.length; index++){
			totalValue += items[index].getRetailValue();
		}
		return totalValue;
	}

	/**
	 * Checks to see if a particular item is in the list.
	 * 
	 * @param itemToFind item to look for
	 * @return true if the item is found in the list, false otherwise
	 */
	public boolean checkAvailability(Listable itemToFind) {

		boolean itemsInlist = false;

		/*Goes Through each item and returns true if the name equals
		 *the name of itemToFiend*/
		for(int index=0; index<items.length; index++){
			if(items[index].equals(itemToFind)){
				itemsInlist=true;
			}
		}
		return itemsInlist;
	}

	/**
	 * Checks if a list of items is contained in the current list.
	 * (In other words, this method will return true if ALL of the items in 
	 * the parameter are contained in the current list.  If anything is missing,
	 * then the return value will be false.)
	 * 
	 * @param listToCheck list of items that may or may not be a subset of the
	 * current list
	 * @return true if the parameter is a subset of the current list; false 
	 * otherwise
	 */
	public boolean checkAvailability(SortedListOfImmutables listToCheck) {

		SortedListOfImmutables itemList = new SortedListOfImmutables(this);

		/*Goes thorugh each item in listToCheck to see if the name is
		 * in items*/
		boolean found=true;
		for(int index1=0; index1<listToCheck.items.length; index1++){
			if(this.checkAvailability(listToCheck.items[index1])==false){
				found = false;
			}
		}
		return found;
	}

	/*
	 * We'll give you this one for free.  Do not modify this method or you
	 * will fail our tests!
	 */
	public String toString() {
		String retValue = "[ ";
		for (int i = 0; i < items.length; i++) {
			if (i != 0) {
				retValue += ", ";
			}
			retValue += items[i];
		}
		retValue += " ]";
		return retValue;
	}
}
