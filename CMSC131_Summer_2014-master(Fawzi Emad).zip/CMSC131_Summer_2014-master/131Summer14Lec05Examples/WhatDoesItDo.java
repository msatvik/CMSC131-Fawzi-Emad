
public class WhatDoesItDo {

	public static void main(String[] args) {
		int x = 4;

		if (x < 3) 
			if (x == 4) 
				System.out.println("X");
		else  
			System.out.println("Y");
	}
}
