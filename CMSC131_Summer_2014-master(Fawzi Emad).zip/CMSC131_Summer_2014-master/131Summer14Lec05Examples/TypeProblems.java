/* Demo of trying to combine types.
 * Some are OK, others are not!! */

public class TypeProblems {

	public static void main(String[] args) {
		int x = 7, y = 12;
		double z = 72.33;
		boolean a = true;
		char b;
		String c;
		
		y = 17.3;
		z = 8;
		a = 17;
	    b = "cow";		
	    c = "Here is something weird " + x + y;
		System.out.println(c);
	}

}