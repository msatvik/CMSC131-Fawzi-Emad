import java.util.Scanner;

public class LogicalOps1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter an integer from 1 to 10: ");
		int value = sc.nextInt();

		if (value >= 1 && value <= 10) {
			System.out.println("Good job!");
		} else {
			System.out.println("You didn't follow instructions!");
		}
	}

}
