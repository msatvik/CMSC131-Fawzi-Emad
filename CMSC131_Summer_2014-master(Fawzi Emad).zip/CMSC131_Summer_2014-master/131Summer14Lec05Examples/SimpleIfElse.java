import java.util.Scanner;

public class SimpleIfElse {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		int value = sc.nextInt();
		
		if (value < 0) {
			System.out.println("That was a negative number!");
			System.out.println("I prefer positive ones, so I'll fix it...");
			value = -value;
		} else {
			System.out.println("That was a positive number!");
			System.out.println("That makes me happy.");
		}
		System.out.println("The number was " + value);
	}
	
}