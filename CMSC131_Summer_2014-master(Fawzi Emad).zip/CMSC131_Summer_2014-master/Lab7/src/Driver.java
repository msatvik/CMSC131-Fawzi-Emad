
public class Driver {
	
	
	public static void main(String[] args){
		
		Warrior guyOne = new Warrior("henry", 10, 200);
		Warrior guyTwo = new Warrior("NecroMite Lord Of the Underworld", 10, 2000);
		Warrior guyThree = new Warrior("Peter", 10, 9999);
		Warrior guyFour = new Warrior("Brian", 10, 1);
		
		System.out.println(Warrior.toString(Warrior.tournament(guyOne, guyTwo, guyThree, guyFour)));
		
	}
	

}
