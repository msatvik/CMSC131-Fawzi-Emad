
public class Warrior {

	public String name;
	public int strength;
	public int healthLevel;

	public  Warrior(String name1, int strength1, int healthLevel1){

		name = name1;
		strength = strength1;
		healthLevel = healthLevel1;
	}

	public Warrior(String ninja){
		name = ninja;
		strength = 10;
		healthLevel = 200;
	}


	public boolean isAlive(){

		if(healthLevel>1){
			return true;
		}
		return false;
	}

	public int smite(Warrior otherWarrior){

		otherWarrior.healthLevel -= strength;
		return otherWarrior.healthLevel;
	}
	
	public boolean equals(Warrior otherWarrior){
		
		return (otherWarrior.strength == strength && otherWarrior.name.equals(name));
		
	}
	
	public static String toString(Warrior person){
			
		return (person.name+" the Barberian - Strength: " +person.strength+", Health: "+person.healthLevel);
	
	}
	
	public static Warrior fight(Warrior firstGuy, Warrior secondGuy){
		
		for(int counter=0; (firstGuy.isAlive() == true) && (secondGuy.isAlive() == true); counter ++){
			if(counter%2==0){
				firstGuy.smite(secondGuy);
			}else{
				secondGuy.smite(firstGuy);
			}
		}
		
		if(firstGuy.isAlive()){
			return firstGuy;
		}else{
			return secondGuy;
		}
		
	}
	
	public static Warrior tournament(Warrior firstGuy, Warrior secondGuy, Warrior thirdGuy, Warrior fourthGuy){
		
		
		return Warrior.fight(Warrior.fight(firstGuy, secondGuy), Warrior.fight(thirdGuy, fourthGuy));
	}
}
