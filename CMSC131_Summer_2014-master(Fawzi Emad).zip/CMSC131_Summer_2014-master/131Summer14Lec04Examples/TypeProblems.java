/* Demo of trying to combine types.
 * Some are OK, others are not!! */

public class TypeProblems {

	public static void main(String[] args) {
		int x = 7, y = 12;
		double d = 72.33;
		boolean b = true;
		char c;
		String s;
		
		x = y + 24;
		y = 17.3;
		d = x;
		b = 17;
	    c = "cow";		
	    s = "Here is something weird " + x + y;
		System.out.println(s);
	}

}