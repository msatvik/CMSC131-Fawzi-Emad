import java.util.Scanner;

public class Scanner1 {

	/**
	 * Shows basic use of the scanner
	 */
	public static void main(String[] args) {
		
		Scanner keyboardInput = new Scanner(System.in);
		
		int first, second;
		
		System.out.print("Enter an integer: ");
		first = keyboardInput.nextInt();
		System.out.println("Enter another integer: ");
		second = keyboardInput.nextInt();
		
		System.out.println("The first number was " + first);
		System.out.println("The second number was " + second);
		
		int sum = first + second;
		int product = first * second;
		System.out.println("Their sum is " + sum);
		System.out.println("Their product is " + product);
	}

}
