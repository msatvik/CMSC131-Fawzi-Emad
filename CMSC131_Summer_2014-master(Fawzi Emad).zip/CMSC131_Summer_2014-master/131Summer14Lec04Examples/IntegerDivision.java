/* CURIOUS...*/

public class IntegerDivision {
	
	public static void main(String[] args) {
		System.out.println("Three divided by four is: " + 3/4);
	}

}