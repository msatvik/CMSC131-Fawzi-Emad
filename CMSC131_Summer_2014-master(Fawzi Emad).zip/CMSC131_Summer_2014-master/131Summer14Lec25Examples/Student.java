public class Student extends Person {
	
	private int admitYear;
	private double gpa;

	public Student() {
		super();                  // super must be first line in constructor
		admitYear = 2000;
		gpa = 4.0;
	}

	public Student(String name, int id, int admitYear, double gpa) {
		super(name, id);
		this.admitYear = admitYear;
		this.gpa = gpa;
	}

	public Student(Student s) {
		super(s);
		admitYear = s.admitYear;
		gpa = s.gpa;
	}

	public boolean equals(Student s) {
		return super.equals(s) && gpa == s.gpa && admitYear == s.admitYear;
	}
	
	public String toString() {
		return super.toString() + ", GPA: " + gpa + ", Admitted: " + admitYear;
	}
	
	
}
