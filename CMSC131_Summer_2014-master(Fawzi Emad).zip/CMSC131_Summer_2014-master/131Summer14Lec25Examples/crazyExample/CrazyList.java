package crazyExample;
import java.util.ArrayList;

public class CrazyList extends ArrayList<String> {

	public void removeStringsThatEndWithZero() {
		for (int i = 0; i < size(); i++) {
			if (get(i).charAt(get(i).length() - 1) == '0') {
				remove(i);
				i--;
			}
		}
	}
	
	public String toString() {
		StringBuffer retValue = new StringBuffer();
		for (String s : this) {

			if (Math.random() < 0.8) {
				retValue.append(s + " ");
			} else {
				retValue.append("CRAZY! ");
			}
		}
		return retValue.toString();
	}

}
