package crazyExample;
import java.util.Collections;

public class Driver {

	public static void main(String[] args) {
		
		CrazyList a = new CrazyList();
		
		for (int i = 0; i < 20; i++) {
			a.add("String #" + i);
		}
		
		Collections.shuffle(a);
		a.removeStringsThatEndWithZero();
		System.out.println("Here is the list: " + a);
	}

}
