public class Faculty extends Person {
	private int hireYear;
	
	public Faculty(String name, int id, int year) {
		super(name, id);
		hireYear = year;
	}
	
	public Faculty(Faculty f) {
		super(f);
		hireYear = f.hireYear;
	}
	
	
}
