
public class Student {
	
	/* instance variables */
	public String name;
	public int IDNum;
	public int tokenLevel;
	
	/* constructors */
	public Student(String nameIn, int IDNumIn, int tokensIn) {
		name = nameIn;
		IDNum = IDNumIn;
		tokenLevel = tokensIn;
	}
	
	public Student(String nameIn, int IDNumIn) {
		name = nameIn;
		IDNum = IDNumIn;
		tokenLevel = 3;
	}
	
	public Student() {
		name = "Unknown";
		IDNum = 0;
		tokenLevel = 3;
	}
	
	public Student(Student otherGuy) {
		name = otherGuy.name;
		IDNum = otherGuy.IDNum;
		tokenLevel = otherGuy.tokenLevel;
	}
	
	/* instance methods */
	public void sayHello() {
		System.out.print("Hi, my name is " + name +
				", and my ID is " + IDNum +
				", and I have " + tokenLevel + " tokens.");
	}
	
	public void spendAToken() {
		tokenLevel--;
	}
	
	public void acceptTokens(int numberAwarded) {
		tokenLevel -= numberAwarded;
	}
	
	public void doAProject(String title, int numPages) {
		System.out.println(name + " is working on " + title);
		for (int page = 1; page <= numPages; page++) {
			System.out.println("done with page " + page);
		}
		System.out.println(name + " is done with " + title);
	}
	
	public int getLastFourDigits() {
		return IDNum % 10000;
	}
	
	public String eatLunch(String food, int numEaten) {
		String answer = name + " is eating ";
		for (int i = 0; i < numEaten; i++) {
			answer = answer + food + " ";
		}
		return answer;
	}
}
