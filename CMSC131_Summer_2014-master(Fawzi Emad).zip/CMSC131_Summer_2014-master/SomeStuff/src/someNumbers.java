
public class someNumbers {

	public static void main(String[] args) {
		/*1)	
		 * Write MATLAB Code to display numbers 2 – 100 
		 * and determine whether or not each number is; even or odd,
		 * and prime or composite. It is ok to write an if statement 
		 * for each prime number, you don’t have to do any fancy division. 
		 * Here is a sample of what your output should look like:
		 * 2	even	prime
		 * 3	odd	prime
		 * 4	even composite */
		
		for(int numb=2; numb<=100;numb++){
			System.out.println(numb);
		}

	}

}
