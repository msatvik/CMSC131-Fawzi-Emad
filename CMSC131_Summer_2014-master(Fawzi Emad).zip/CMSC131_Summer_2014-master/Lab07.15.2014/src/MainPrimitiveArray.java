
public class MainPrimitiveArray {

	public static void main(String[] args) {
		
	  arrayPassedIn(0,1,2,3,0,4,5,0);
	}
	
	public static int arrayPassedIn(){
		
		
		return a;
	}

}
