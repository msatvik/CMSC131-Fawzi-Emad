
public class PrimitiveArrays {
	

	
	public static int arraysIn(int[]arrayOne){    
	    
		int[] arrayTwo = new int[arrayOne.length];
		
	    for(int i=0; i<arrayOne.length; i++){
	    	arrayOne[i]= arrayTwo[i];
	    	
	    }
	    return arrayTwo;
	}
	
	public boolean arrayBoolean(boolean []arrayOne){
		
		for(int i=0;i<arrayOne.length; i++){
			if(){
				
				
			}
			
		}
	}
	
	public static int randomIntegers(int randomInts){
		
		Math.ra
	}
	

}
