
import java.util.*;

public class StringTools {
	

	
	public static int count(String a, char c){
		
		a = "concurrent";
		int charCount = a.indexOf(c);
		return charCount;
		
	}
	
	public static int countSubstring(String a, String b){
		
		a = "mississipi";
		b = "issi";
		int substringCount = a.
	}
	
	public static String reverse(String a){
		
		StringBuilder sb = new StringBuilder();
		
		for  (int i = a.length()-1; i>=0; --i){
			sb.append(a.charAt(i));
			return sb.toString();
		}
		return a;
		
		
	}
	
	public static String expand(String a){
		//one for loop counts the string
		//other for loop does concatination
		for(int i = a.length(); i>=0; i--){
			int countNumberOfLetters = i;
			for(int j = 0; j<=a.length()-i ; j++){
			 	a.charAt(i-1);
			 	
			}
		return a;
		}
		
	}
	
	public static String alternating(String a, String b){
		
		
	}
	
	public static String LinkExtractor(String a){
		
	}
	

}
